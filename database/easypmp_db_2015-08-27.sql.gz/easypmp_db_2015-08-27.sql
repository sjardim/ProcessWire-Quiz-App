# ************************************************************
# Sequel Pro SQL dump
# Version 4135
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: localhost (MySQL 5.5.42)
# Database: easypmp_db
# Generation Time: 2015-08-27 05:39:54 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table caches
# ------------------------------------------------------------

DROP TABLE IF EXISTS `caches`;

CREATE TABLE `caches` (
  `name` varchar(255) NOT NULL,
  `data` mediumtext NOT NULL,
  `expires` datetime NOT NULL,
  PRIMARY KEY (`name`),
  KEY `expires` (`expires`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `caches` WRITE;
/*!40000 ALTER TABLE `caches` DISABLE KEYS */;

INSERT INTO `caches` (`name`, `data`, `expires`)
VALUES
	('Modules.wire/modules/','AdminTheme/AdminThemeDefault/AdminThemeDefault.module\nAdminTheme/AdminThemeReno/AdminThemeReno.module\nFieldtype/FieldtypeCache.module\nFieldtype/FieldtypeCheckbox.module\nFieldtype/FieldtypeComments/CommentFilterAkismet.module\nFieldtype/FieldtypeComments/FieldtypeComments.module\nFieldtype/FieldtypeComments/InputfieldCommentsAdmin.module\nFieldtype/FieldtypeDatetime.module\nFieldtype/FieldtypeEmail.module\nFieldtype/FieldtypeFieldsetClose.module\nFieldtype/FieldtypeFieldsetOpen.module\nFieldtype/FieldtypeFieldsetTabOpen.module\nFieldtype/FieldtypeFile.module\nFieldtype/FieldtypeFloat.module\nFieldtype/FieldtypeImage.module\nFieldtype/FieldtypeInteger.module\nFieldtype/FieldtypeModule.module\nFieldtype/FieldtypeOptions/FieldtypeOptions.module\nFieldtype/FieldtypePage.module\nFieldtype/FieldtypePageTable.module\nFieldtype/FieldtypePageTitle.module\nFieldtype/FieldtypePassword.module\nFieldtype/FieldtypeRepeater/FieldtypeRepeater.module\nFieldtype/FieldtypeRepeater/InputfieldRepeater.module\nFieldtype/FieldtypeSelector.module\nFieldtype/FieldtypeText.module\nFieldtype/FieldtypeTextarea.module\nFieldtype/FieldtypeURL.module\nInputfield/InputfieldAsmSelect/InputfieldAsmSelect.module\nInputfield/InputfieldButton.module\nInputfield/InputfieldCheckbox.module\nInputfield/InputfieldCheckboxes/InputfieldCheckboxes.module\nInputfield/InputfieldCKEditor/InputfieldCKEditor.module\nInputfield/InputfieldDatetime/InputfieldDatetime.module\nInputfield/InputfieldEmail.module\nInputfield/InputfieldFieldset.module\nInputfield/InputfieldFile/InputfieldFile.module\nInputfield/InputfieldFloat.module\nInputfield/InputfieldForm.module\nInputfield/InputfieldHidden.module\nInputfield/InputfieldIcon/InputfieldIcon.module\nInputfield/InputfieldImage/InputfieldImage.module\nInputfield/InputfieldInteger.module\nInputfield/InputfieldMarkup.module\nInputfield/InputfieldName.module\nInputfield/InputfieldPage/InputfieldPage.module\nInputfield/InputfieldPageAutocomplete/InputfieldPageAutocomplete.module\nInputfield/InputfieldPageListSelect/InputfieldPageListSelect.module\nInputfield/InputfieldPageListSelect/InputfieldPageListSelectMultiple.module\nInputfield/InputfieldPageName/InputfieldPageName.module\nInputfield/InputfieldPageTable/InputfieldPageTable.module\nInputfield/InputfieldPageTitle/InputfieldPageTitle.module\nInputfield/InputfieldPassword.module\nInputfield/InputfieldRadios/InputfieldRadios.module\nInputfield/InputfieldSelect.module\nInputfield/InputfieldSelectMultiple.module\nInputfield/InputfieldSelector/InputfieldSelector.module\nInputfield/InputfieldSubmit/InputfieldSubmit.module\nInputfield/InputfieldText.module\nInputfield/InputfieldTextarea.module\nInputfield/InputfieldURL.module\nJquery/JqueryCore/JqueryCore.module\nJquery/JqueryFancybox/JqueryFancybox.module\nJquery/JqueryMagnific/JqueryMagnific.module\nJquery/JqueryTableSorter/JqueryTableSorter.module\nJquery/JqueryUI/JqueryUI.module\nJquery/JqueryWireTabs/JqueryWireTabs.module\nLanguageSupport/FieldtypePageTitleLanguage.module\nLanguageSupport/FieldtypeTextareaLanguage.module\nLanguageSupport/FieldtypeTextLanguage.module\nLanguageSupport/LanguageSupport.module\nLanguageSupport/LanguageSupportFields.module\nLanguageSupport/LanguageSupportPageNames.module\nLanguageSupport/LanguageTabs.module\nLanguageSupport/ProcessLanguage.module\nLanguageSupport/ProcessLanguageTranslator.module\nLazyCron.module\nMarkup/MarkupAdminDataTable/MarkupAdminDataTable.module\nMarkup/MarkupCache.module\nMarkup/MarkupHTMLPurifier/MarkupHTMLPurifier.module\nMarkup/MarkupPageArray.module\nMarkup/MarkupPageFields.module\nMarkup/MarkupPagerNav/MarkupPagerNav.module\nMarkup/MarkupRSS.module\nPagePathHistory.module\nPagePaths.module\nPagePermissions.module\nPageRender.module\nProcess/ProcessCommentsManager/ProcessCommentsManager.module\nProcess/ProcessField/ProcessField.module\nProcess/ProcessForgotPassword.module\nProcess/ProcessHome.module\nProcess/ProcessList.module\nProcess/ProcessLogger/ProcessLogger.module\nProcess/ProcessLogin/ProcessLogin.module\nProcess/ProcessModule/ProcessModule.module\nProcess/ProcessPageAdd/ProcessPageAdd.module\nProcess/ProcessPageClone.module\nProcess/ProcessPageEdit/ProcessPageEdit.module\nProcess/ProcessPageEditImageSelect/ProcessPageEditImageSelect.module\nProcess/ProcessPageEditLink/ProcessPageEditLink.module\nProcess/ProcessPageList/ProcessPageList.module\nProcess/ProcessPageLister/ProcessPageLister.module\nProcess/ProcessPageSearch/ProcessPageSearch.module\nProcess/ProcessPageSort.module\nProcess/ProcessPageTrash.module\nProcess/ProcessPageType/ProcessPageType.module\nProcess/ProcessPageView.module\nProcess/ProcessPermission/ProcessPermission.module\nProcess/ProcessProfile/ProcessProfile.module\nProcess/ProcessRecentPages/ProcessRecentPages.module\nProcess/ProcessRole/ProcessRole.module\nProcess/ProcessTemplate/ProcessTemplate.module\nProcess/ProcessUser/ProcessUser.module\nSession/SessionHandlerDB/ProcessSessionDB.module\nSession/SessionHandlerDB/SessionHandlerDB.module\nSession/SessionLoginThrottle/SessionLoginThrottle.module\nSystem/SystemNotifications/FieldtypeNotifications.module\nSystem/SystemNotifications/SystemNotifications.module\nSystem/SystemUpdater/SystemUpdater.module\nTextformatter/TextformatterEntities.module\nTextformatter/TextformatterMarkdownExtra/TextformatterMarkdownExtra.module\nTextformatter/TextformatterNewlineBR.module\nTextformatter/TextformatterNewlineUL.module\nTextformatter/TextformatterPstripper.module\nTextformatter/TextformatterSmartypants/TextformatterSmartypants.module\nTextformatter/TextformatterStripTags.module','2010-04-08 03:10:10'),
	('Modules.info','{\"148\":{\"name\":\"AdminThemeDefault\",\"title\":\"Default\",\"version\":14,\"autoload\":\"template=admin\",\"configurable\":19},\"171\":{\"name\":\"AdminThemeReno\",\"title\":\"Reno\",\"version\":17,\"requiresVersions\":{\"AdminThemeDefault\":[\">=\",0]},\"autoload\":\"template=admin\",\"created\":1440527810,\"configurable\":true},\"97\":{\"name\":\"FieldtypeCheckbox\",\"title\":\"Checkbox\",\"version\":101,\"singular\":true,\"permanent\":true},\"28\":{\"name\":\"FieldtypeDatetime\",\"title\":\"Datetime\",\"version\":104},\"29\":{\"name\":\"FieldtypeEmail\",\"title\":\"E-Mail\",\"version\":100},\"106\":{\"name\":\"FieldtypeFieldsetClose\",\"title\":\"Fieldset (Close)\",\"version\":100,\"singular\":1,\"permanent\":true},\"105\":{\"name\":\"FieldtypeFieldsetOpen\",\"title\":\"Fieldset (Open)\",\"version\":100,\"singular\":1,\"permanent\":true},\"107\":{\"name\":\"FieldtypeFieldsetTabOpen\",\"title\":\"Fieldset in Tab (Open)\",\"version\":100,\"singular\":1,\"permanent\":true},\"6\":{\"name\":\"FieldtypeFile\",\"title\":\"Files\",\"version\":104,\"permanent\":true},\"89\":{\"name\":\"FieldtypeFloat\",\"title\":\"Float\",\"version\":105,\"singular\":1,\"permanent\":true},\"57\":{\"name\":\"FieldtypeImage\",\"title\":\"Images\",\"version\":101,\"permanent\":true},\"84\":{\"name\":\"FieldtypeInteger\",\"title\":\"Integer\",\"version\":101,\"permanent\":true},\"27\":{\"name\":\"FieldtypeModule\",\"title\":\"Module Reference\",\"version\":101,\"permanent\":true},\"4\":{\"name\":\"FieldtypePage\",\"title\":\"Page Reference\",\"version\":102,\"configurable\":true,\"permanent\":true},\"177\":{\"name\":\"FieldtypePageTable\",\"title\":\"ProFields: Page Table\",\"version\":8,\"installs\":[\"InputfieldPageTable\"],\"autoload\":true,\"singular\":true,\"created\":1440530897},\"111\":{\"name\":\"FieldtypePageTitle\",\"title\":\"Page Title\",\"version\":100,\"singular\":1,\"permanent\":true},\"133\":{\"name\":\"FieldtypePassword\",\"title\":\"Password\",\"version\":101,\"singular\":true,\"permanent\":true},\"172\":{\"name\":\"FieldtypeRepeater\",\"title\":\"Repeater\",\"version\":102,\"installs\":[\"InputfieldRepeater\"],\"autoload\":true,\"singular\":true,\"created\":1440528404,\"configurable\":true},\"173\":{\"name\":\"InputfieldRepeater\",\"title\":\"Repeater\",\"version\":102,\"requiresVersions\":{\"FieldtypeRepeater\":[\">=\",0]},\"created\":1440528404},\"174\":{\"name\":\"FieldtypeSelector\",\"title\":\"Selector\",\"version\":13,\"singular\":1,\"created\":1440528434},\"3\":{\"name\":\"FieldtypeText\",\"title\":\"Text\",\"version\":100,\"permanent\":true},\"1\":{\"name\":\"FieldtypeTextarea\",\"title\":\"Textarea\",\"version\":104,\"permanent\":true},\"135\":{\"name\":\"FieldtypeURL\",\"title\":\"URL\",\"version\":100,\"singular\":1,\"permanent\":true},\"25\":{\"name\":\"InputfieldAsmSelect\",\"title\":\"asmSelect\",\"version\":118,\"permanent\":true},\"131\":{\"name\":\"InputfieldButton\",\"title\":\"Button\",\"version\":100,\"permanent\":true},\"37\":{\"name\":\"InputfieldCheckbox\",\"title\":\"Checkbox\",\"version\":104,\"permanent\":true},\"38\":{\"name\":\"InputfieldCheckboxes\",\"title\":\"Checkboxes\",\"version\":107,\"permanent\":true},\"155\":{\"name\":\"InputfieldCKEditor\",\"title\":\"CKEditor\",\"version\":153,\"installs\":[\"MarkupHTMLPurifier\"],\"created\":1406294777},\"94\":{\"name\":\"InputfieldDatetime\",\"title\":\"Datetime\",\"version\":104,\"permanent\":true},\"80\":{\"name\":\"InputfieldEmail\",\"title\":\"Email\",\"version\":101},\"78\":{\"name\":\"InputfieldFieldset\",\"title\":\"Fieldset\",\"version\":101,\"permanent\":true},\"55\":{\"name\":\"InputfieldFile\",\"title\":\"Files\",\"version\":124,\"permanent\":true},\"90\":{\"name\":\"InputfieldFloat\",\"title\":\"Float\",\"version\":103,\"permanent\":true},\"30\":{\"name\":\"InputfieldForm\",\"title\":\"Form\",\"version\":106,\"permanent\":true},\"40\":{\"name\":\"InputfieldHidden\",\"title\":\"Hidden\",\"version\":101,\"permanent\":true},\"170\":{\"name\":\"InputfieldIcon\",\"title\":\"Icon\",\"version\":2,\"created\":1440527774},\"56\":{\"name\":\"InputfieldImage\",\"title\":\"Images\",\"version\":116,\"permanent\":true},\"85\":{\"name\":\"InputfieldInteger\",\"title\":\"Integer\",\"version\":103,\"permanent\":true},\"79\":{\"name\":\"InputfieldMarkup\",\"title\":\"Markup\",\"version\":102,\"permanent\":true},\"41\":{\"name\":\"InputfieldName\",\"title\":\"Name\",\"version\":100,\"permanent\":true},\"60\":{\"name\":\"InputfieldPage\",\"title\":\"Page\",\"version\":106,\"configurable\":true,\"permanent\":true},\"15\":{\"name\":\"InputfieldPageListSelect\",\"title\":\"Page List Select\",\"version\":101,\"permanent\":true},\"137\":{\"name\":\"InputfieldPageListSelectMultiple\",\"title\":\"Page List Select Multiple\",\"version\":102,\"permanent\":true},\"86\":{\"name\":\"InputfieldPageName\",\"title\":\"Page Name\",\"version\":106,\"configurable\":true,\"permanent\":true},\"178\":{\"name\":\"InputfieldPageTable\",\"title\":\"ProFields: Page Table\",\"version\":12,\"requiresVersions\":{\"FieldtypePageTable\":[\">=\",0]},\"created\":1440530897},\"112\":{\"name\":\"InputfieldPageTitle\",\"title\":\"Page Title\",\"version\":102,\"permanent\":true},\"122\":{\"name\":\"InputfieldPassword\",\"title\":\"Password\",\"version\":101,\"permanent\":true},\"39\":{\"name\":\"InputfieldRadios\",\"title\":\"Radio Buttons\",\"version\":105,\"permanent\":true},\"36\":{\"name\":\"InputfieldSelect\",\"title\":\"Select\",\"version\":102,\"permanent\":true},\"43\":{\"name\":\"InputfieldSelectMultiple\",\"title\":\"Select Multiple\",\"version\":101,\"permanent\":true},\"149\":{\"name\":\"InputfieldSelector\",\"title\":\"Selector\",\"version\":26,\"autoload\":\"template=admin\",\"configurable\":true},\"32\":{\"name\":\"InputfieldSubmit\",\"title\":\"Submit\",\"version\":101,\"permanent\":true},\"34\":{\"name\":\"InputfieldText\",\"title\":\"Text\",\"version\":105,\"permanent\":true},\"35\":{\"name\":\"InputfieldTextarea\",\"title\":\"Textarea\",\"version\":103,\"permanent\":true},\"108\":{\"name\":\"InputfieldURL\",\"title\":\"URL\",\"version\":101},\"116\":{\"name\":\"JqueryCore\",\"title\":\"jQuery Core\",\"version\":183,\"singular\":true,\"permanent\":true},\"151\":{\"name\":\"JqueryMagnific\",\"title\":\"jQuery Magnific Popup\",\"version\":1,\"singular\":1,\"created\":1405938105},\"103\":{\"name\":\"JqueryTableSorter\",\"title\":\"jQuery Table Sorter Plugin\",\"version\":221,\"singular\":1},\"117\":{\"name\":\"JqueryUI\",\"title\":\"jQuery UI\",\"version\":196,\"singular\":true,\"permanent\":true},\"45\":{\"name\":\"JqueryWireTabs\",\"title\":\"jQuery Wire Tabs Plugin\",\"version\":107,\"configurable\":true,\"permanent\":true},\"163\":{\"name\":\"FieldtypePageTitleLanguage\",\"title\":\"Page Title (Multi-Language)\",\"version\":100,\"requiresVersions\":{\"LanguageSupportFields\":[\">=\",0],\"FieldtypeTextLanguage\":[\">=\",0]},\"singular\":true,\"created\":1409647556},\"164\":{\"name\":\"FieldtypeTextareaLanguage\",\"title\":\"Textarea (Multi-language)\",\"version\":100,\"requiresVersions\":{\"LanguageSupportFields\":[\">=\",0]},\"singular\":true,\"created\":1409647556},\"162\":{\"name\":\"FieldtypeTextLanguage\",\"title\":\"Text (Multi-language)\",\"version\":100,\"requiresVersions\":{\"LanguageSupportFields\":[\">=\",0]},\"singular\":true,\"created\":1409647556},\"158\":{\"name\":\"LanguageSupport\",\"title\":\"Languages Support\",\"version\":103,\"installs\":[\"ProcessLanguage\",\"ProcessLanguageTranslator\"],\"autoload\":true,\"singular\":true,\"created\":1409647546,\"configurable\":true},\"161\":{\"name\":\"LanguageSupportFields\",\"title\":\"Languages Support - Fields\",\"version\":100,\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"installs\":[\"FieldtypePageTitleLanguage\",\"FieldtypeTextareaLanguage\",\"FieldtypeTextLanguage\"],\"autoload\":true,\"singular\":true,\"created\":1409647556},\"165\":{\"name\":\"LanguageSupportPageNames\",\"title\":\"Languages Support - Page Names\",\"version\":9,\"requiresVersions\":{\"LanguageSupport\":[\">=\",0],\"LanguageSupportFields\":[\">=\",0]},\"autoload\":true,\"singular\":true,\"created\":1409647561,\"configurable\":true},\"166\":{\"name\":\"LanguageTabs\",\"title\":\"Languages Support - Tabs\",\"version\":113,\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"autoload\":\"template=admin\",\"singular\":true,\"created\":1409647572},\"159\":{\"name\":\"ProcessLanguage\",\"title\":\"Languages\",\"version\":102,\"icon\":\"language\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"singular\":1,\"created\":1409647546,\"configurable\":true,\"useNavJSON\":true},\"160\":{\"name\":\"ProcessLanguageTranslator\",\"title\":\"Language Translator\",\"version\":100,\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"singular\":1,\"created\":1409647546},\"67\":{\"name\":\"MarkupAdminDataTable\",\"title\":\"Admin Data Table\",\"version\":107,\"permanent\":true},\"156\":{\"name\":\"MarkupHTMLPurifier\",\"title\":\"HTML Purifier\",\"version\":104,\"created\":1406294777},\"113\":{\"name\":\"MarkupPageArray\",\"title\":\"PageArray Markup\",\"version\":100,\"autoload\":true,\"singular\":true},\"98\":{\"name\":\"MarkupPagerNav\",\"title\":\"Pager (Pagination) Navigation\",\"version\":103},\"152\":{\"name\":\"PagePathHistory\",\"title\":\"Page Path History\",\"version\":1,\"autoload\":true,\"singular\":true,\"created\":1406291817},\"114\":{\"name\":\"PagePermissions\",\"title\":\"Page Permissions\",\"version\":105,\"autoload\":true,\"singular\":true,\"permanent\":true},\"115\":{\"name\":\"PageRender\",\"title\":\"Page Render\",\"version\":103,\"autoload\":true,\"singular\":true,\"configurable\":true,\"permanent\":true},\"48\":{\"name\":\"ProcessField\",\"title\":\"Fields\",\"version\":111,\"icon\":\"cube\",\"permission\":\"field-admin\",\"configurable\":true,\"permanent\":true,\"useNavJSON\":true},\"176\":{\"name\":\"ProcessForgotPassword\",\"title\":\"Forgot Password\",\"version\":101,\"permission\":\"page-view\",\"singular\":1,\"created\":1440530761,\"configurable\":true},\"87\":{\"name\":\"ProcessHome\",\"title\":\"Admin Home\",\"version\":101,\"permission\":\"page-view\",\"permanent\":true},\"76\":{\"name\":\"ProcessList\",\"title\":\"List\",\"version\":101,\"permission\":\"page-view\",\"permanent\":true},\"169\":{\"name\":\"ProcessLogger\",\"title\":\"Logs\",\"version\":1,\"icon\":\"tree\",\"permission\":\"logs-view\",\"singular\":1,\"created\":1440527774,\"useNavJSON\":true},\"10\":{\"name\":\"ProcessLogin\",\"title\":\"Login\",\"version\":103,\"permission\":\"page-view\",\"permanent\":true},\"50\":{\"name\":\"ProcessModule\",\"title\":\"Modules\",\"version\":118,\"permission\":\"module-admin\",\"permanent\":true,\"useNavJSON\":true,\"nav\":[{\"url\":\"?site#tab_site_modules\",\"label\":\"Site\",\"icon\":\"plug\",\"navJSON\":\"navJSON\\/?site=1\"},{\"url\":\"?core#tab_core_modules\",\"label\":\"Core\",\"icon\":\"plug\",\"navJSON\":\"navJSON\\/?core=1\"},{\"url\":\"?configurable#tab_configurable_modules\",\"label\":\"Configure\",\"icon\":\"gear\",\"navJSON\":\"navJSON\\/?configurable=1\"},{\"url\":\"?install#tab_install_modules\",\"label\":\"Install\",\"icon\":\"sign-in\",\"navJSON\":\"navJSON\\/?install=1\"},{\"url\":\"?reset=1\",\"label\":\"Refresh\",\"icon\":\"refresh\"}]},\"17\":{\"name\":\"ProcessPageAdd\",\"title\":\"Page Add\",\"version\":108,\"icon\":\"plus-circle\",\"permission\":\"page-edit\",\"configurable\":true,\"permanent\":true,\"useNavJSON\":true},\"7\":{\"name\":\"ProcessPageEdit\",\"title\":\"Page Edit\",\"version\":108,\"permission\":\"page-edit\",\"singular\":1,\"permanent\":true},\"129\":{\"name\":\"ProcessPageEditImageSelect\",\"title\":\"Page Edit Image\",\"version\":119,\"permission\":\"page-edit\",\"singular\":1,\"configurable\":true,\"permanent\":true},\"121\":{\"name\":\"ProcessPageEditLink\",\"title\":\"Page Edit Link\",\"version\":108,\"icon\":\"link\",\"permission\":\"page-edit\",\"singular\":1,\"configurable\":true,\"permanent\":true},\"12\":{\"name\":\"ProcessPageList\",\"title\":\"Page List\",\"version\":117,\"icon\":\"sitemap\",\"permission\":\"page-edit\",\"configurable\":true,\"permanent\":true},\"150\":{\"name\":\"ProcessPageLister\",\"title\":\"Lister\",\"version\":24,\"icon\":\"search\",\"permission\":\"page-lister\",\"configurable\":true,\"permanent\":true},\"104\":{\"name\":\"ProcessPageSearch\",\"title\":\"Page Search\",\"version\":106,\"permission\":\"page-edit\",\"singular\":1,\"configurable\":true,\"permanent\":true},\"14\":{\"name\":\"ProcessPageSort\",\"title\":\"Page Sort and Move\",\"version\":100,\"permission\":\"page-edit\",\"permanent\":true},\"109\":{\"name\":\"ProcessPageTrash\",\"title\":\"Page Trash\",\"version\":101,\"singular\":1,\"permanent\":true},\"134\":{\"name\":\"ProcessPageType\",\"title\":\"Page Type\",\"version\":101,\"singular\":1,\"configurable\":true,\"permanent\":true,\"useNavJSON\":true},\"83\":{\"name\":\"ProcessPageView\",\"title\":\"Page View\",\"version\":103,\"permission\":\"page-view\",\"permanent\":true},\"136\":{\"name\":\"ProcessPermission\",\"title\":\"Permissions\",\"version\":100,\"icon\":\"gear\",\"permission\":\"permission-admin\",\"singular\":1,\"configurable\":true,\"permanent\":true,\"useNavJSON\":true},\"138\":{\"name\":\"ProcessProfile\",\"title\":\"User Profile\",\"version\":101,\"permission\":\"profile-edit\",\"singular\":1,\"configurable\":true,\"permanent\":true},\"168\":{\"name\":\"ProcessRecentPages\",\"title\":\"Recent Pages\",\"version\":2,\"icon\":\"clock-o\",\"permission\":\"page-edit-recent\",\"singular\":1,\"created\":1440527762,\"useNavJSON\":true,\"nav\":[{\"url\":\"?edited=1\",\"label\":\"Edited\",\"icon\":\"users\",\"navJSON\":\"navJSON\\/?edited=1\"},{\"url\":\"?added=1\",\"label\":\"Created\",\"icon\":\"users\",\"navJSON\":\"navJSON\\/?added=1&me=1\"},{\"url\":\"?edited=1&me=1\",\"label\":\"Edited by me\",\"icon\":\"user\",\"navJSON\":\"navJSON\\/?edited=1&me=1\"},{\"url\":\"?added=1&me=1\",\"label\":\"Created by me\",\"icon\":\"user\",\"navJSON\":\"navJSON\\/?added=1&me=1\"},{\"url\":\"another\\/\",\"label\":\"Add another\",\"icon\":\"plus-circle\",\"navJSON\":\"anotherNavJSON\\/\"}]},\"68\":{\"name\":\"ProcessRole\",\"title\":\"Roles\",\"version\":102,\"icon\":\"gears\",\"permission\":\"role-admin\",\"configurable\":true,\"permanent\":true,\"useNavJSON\":true},\"47\":{\"name\":\"ProcessTemplate\",\"title\":\"Templates\",\"version\":113,\"icon\":\"cubes\",\"permission\":\"template-admin\",\"permanent\":true,\"useNavJSON\":true},\"66\":{\"name\":\"ProcessUser\",\"title\":\"Users\",\"version\":106,\"icon\":\"group\",\"permission\":\"user-admin\",\"configurable\":\"ProcessUserConfig.php\",\"permanent\":true,\"useNavJSON\":true},\"125\":{\"name\":\"SessionLoginThrottle\",\"title\":\"Session Login Throttle\",\"version\":102,\"autoload\":\"function\",\"singular\":true,\"configurable\":true},\"139\":{\"name\":\"SystemUpdater\",\"title\":\"System Updater\",\"version\":11,\"singular\":true,\"configurable\":true,\"permanent\":true},\"61\":{\"name\":\"TextformatterEntities\",\"title\":\"HTML Entity Encoder (htmlspecialchars)\",\"version\":100},\"175\":{\"name\":\"ProcessRedirectIds\",\"title\":\"Redirect ID based URLs\",\"version\":29,\"icon\":\"arrow-circle-right\",\"autoload\":true,\"singular\":true,\"created\":1440529858,\"configurable\":true},\"179\":{\"name\":\"GenerateQuestionShortTitle\",\"title\":\"Generate Question Short Title\",\"version\":1,\"autoload\":true,\"singular\":true}}','2010-04-08 03:10:10'),
	('ModulesUninstalled.info','{\"FieldtypeCache\":{\"name\":\"FieldtypeCache\",\"title\":\"Cache\",\"version\":101,\"versionStr\":\"1.0.1\",\"summary\":\"Caches the values of other fields for fewer runtime queries. Can also be used to combine multiple text fields and have them all be searchable under the cached field name.\",\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeCache.module\",\"core\":true},\"CommentFilterAkismet\":{\"name\":\"CommentFilterAkismet\",\"title\":\"Comment Filter: Akismet\",\"version\":102,\"versionStr\":\"1.0.2\",\"summary\":\"Uses the Akismet service to identify comment spam. Module plugin for the Comments Fieldtype.\",\"requiresVersions\":{\"FieldtypeComments\":[\">=\",0]},\"created\":1440167712,\"installed\":false,\"configurable\":true,\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeComments\\/CommentFilterAkismet.module\",\"core\":true},\"FieldtypeComments\":{\"name\":\"FieldtypeComments\",\"title\":\"Comments\",\"version\":106,\"versionStr\":\"1.0.6\",\"summary\":\"Field that stores user posted comments for a single Page\",\"installs\":[\"InputfieldCommentsAdmin\"],\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeComments\\/FieldtypeComments.module\",\"core\":true},\"InputfieldCommentsAdmin\":{\"name\":\"InputfieldCommentsAdmin\",\"title\":\"Comments Admin\",\"version\":104,\"versionStr\":\"1.0.4\",\"summary\":\"Provides an administrative interface for working with comments\",\"requiresVersions\":{\"FieldtypeComments\":[\">=\",0]},\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeComments\\/InputfieldCommentsAdmin.module\",\"core\":true},\"FieldtypeOptions\":{\"name\":\"FieldtypeOptions\",\"title\":\"Select Options\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Field that stores single and multi select options.\",\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeOptions\\/FieldtypeOptions.module\",\"core\":true},\"InputfieldPageAutocomplete\":{\"name\":\"InputfieldPageAutocomplete\",\"title\":\"Page Auto Complete\",\"version\":110,\"versionStr\":\"1.1.0\",\"summary\":\"Multiple Page selection using auto completion and sorting capability. Intended for use as an input field for Page reference fields.\",\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldPageAutocomplete\\/InputfieldPageAutocomplete.module\",\"core\":true},\"JqueryFancybox\":{\"name\":\"JqueryFancybox\",\"title\":\"jQuery Fancybox Plugin\",\"version\":126,\"versionStr\":\"1.2.6\",\"summary\":\"Provides lightbox capability for image galleries. jQuery plugin by Janis Skarnelis.\",\"href\":\"http:\\/\\/fancybox.net\",\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/Jquery\\/JqueryFancybox\\/JqueryFancybox.module\",\"core\":true},\"LazyCron\":{\"name\":\"LazyCron\",\"title\":\"Lazy Cron\",\"version\":102,\"versionStr\":\"1.0.2\",\"summary\":\"Provides hooks that are automatically executed at various intervals. It is called \'lazy\' because it\'s triggered by a pageview, so the interval is guaranteed to be at least the time requested, rather than exactly the time requested. This is fine for most cases, but you can make it not lazy by connecting this to a real CRON job. See the module file for details. \",\"href\":\"http:\\/\\/processwire.com\\/talk\\/index.php\\/topic,284.0.html\",\"autoload\":true,\"singular\":true,\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/LazyCron.module\",\"core\":true},\"MarkupCache\":{\"name\":\"MarkupCache\",\"title\":\"Markup Cache\",\"version\":101,\"versionStr\":\"1.0.1\",\"summary\":\"A simple way to cache segments of markup in your templates. \",\"href\":\"http:\\/\\/www.processwire.com\\/api\\/modules\\/markupcache\\/\",\"autoload\":true,\"singular\":true,\"created\":1440167712,\"installed\":false,\"configurable\":true,\"file\":\"wire\\/modules\\/Markup\\/MarkupCache.module\",\"core\":true},\"MarkupPageFields\":{\"name\":\"MarkupPageFields\",\"title\":\"Markup Page Fields\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Adds $page->renderFields() and $page->images->render() methods that return basic markup for output during development and debugging.\",\"autoload\":true,\"singular\":true,\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/Markup\\/MarkupPageFields.module\",\"core\":true,\"permanent\":true},\"MarkupRSS\":{\"name\":\"MarkupRSS\",\"title\":\"Markup RSS Feed\",\"version\":102,\"versionStr\":\"1.0.2\",\"summary\":\"Renders an RSS feed. Given a PageArray, renders an RSS feed of them.\",\"created\":1440167712,\"installed\":false,\"configurable\":true,\"file\":\"wire\\/modules\\/Markup\\/MarkupRSS.module\",\"core\":true},\"PagePaths\":{\"name\":\"PagePaths\",\"title\":\"Page Paths\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Enables page paths\\/urls to be queryable by selectors. Also offers potential for improved load performance. Builds an index at install (may take time on a large site). Currently supports only single languages sites.\",\"autoload\":true,\"singular\":true,\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/PagePaths.module\",\"core\":true},\"ProcessCommentsManager\":{\"name\":\"ProcessCommentsManager\",\"title\":\"Comments\",\"version\":5,\"versionStr\":\"0.0.5\",\"author\":\"Ryan Cramer\",\"summary\":\"Manage comments in your site outside of the page editor.\",\"icon\":\"comments\",\"requiresVersions\":{\"FieldtypeComments\":[\">=\",0]},\"permission\":\"comments-manager\",\"permissions\":{\"comments-manager\":\"Use the comments manager\"},\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/Process\\/ProcessCommentsManager\\/ProcessCommentsManager.module\",\"core\":true,\"page\":{\"name\":\"comments\",\"parent\":\"setup\",\"title\":\"Comments\"},\"nav\":[{\"url\":\"?go=approved\",\"label\":\"Approved\"},{\"url\":\"?go=pending\",\"label\":\"Pending\"},{\"url\":\"?go=spam\",\"label\":\"Spam\"},{\"url\":\"?go=all\",\"label\":\"All\"}]},\"ProcessPageClone\":{\"name\":\"ProcessPageClone\",\"title\":\"Page Clone\",\"version\":103,\"versionStr\":\"1.0.3\",\"summary\":\"Provides ability to clone\\/copy\\/duplicate pages in the admin. Adds a &quot;copy&quot; option to all applicable pages in the PageList.\",\"permission\":\"page-clone\",\"permissions\":{\"page-clone\":\"Clone a page\",\"page-clone-tree\":\"Clone a tree of pages\"},\"autoload\":\"template=admin\",\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/Process\\/ProcessPageClone.module\",\"core\":true,\"page\":{\"name\":\"clone\",\"title\":\"Clone\",\"parent\":\"page\",\"status\":1024}},\"ProcessSessionDB\":{\"name\":\"ProcessSessionDB\",\"title\":\"Sessions\",\"version\":3,\"versionStr\":\"0.0.3\",\"summary\":\"Enables you to browse active database sessions.\",\"icon\":\"dashboard\",\"requiresVersions\":{\"SessionHandlerDB\":[\">=\",0]},\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/Session\\/SessionHandlerDB\\/ProcessSessionDB.module\",\"core\":true},\"SessionHandlerDB\":{\"name\":\"SessionHandlerDB\",\"title\":\"Session Handler Database\",\"version\":2,\"versionStr\":\"0.0.2\",\"summary\":\"Installing this module makes ProcessWire store sessions in the database rather than the file system. Note that this module will log you out after install or uninstall.\",\"installs\":[\"ProcessSessionDB\"],\"created\":1440167712,\"installed\":false,\"configurable\":true,\"file\":\"wire\\/modules\\/Session\\/SessionHandlerDB\\/SessionHandlerDB.module\",\"core\":true},\"FieldtypeNotifications\":{\"name\":\"FieldtypeNotifications\",\"title\":\"Notifications\",\"version\":4,\"versionStr\":\"0.0.4\",\"summary\":\"Field that stores user notifications.\",\"requiresVersions\":{\"SystemNotifications\":[\">=\",0]},\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/System\\/SystemNotifications\\/FieldtypeNotifications.module\",\"core\":true},\"SystemNotifications\":{\"name\":\"SystemNotifications\",\"title\":\"System Notifications\",\"version\":12,\"versionStr\":\"0.1.2\",\"summary\":\"Adds support for notifications in ProcessWire (currently in development)\",\"icon\":\"bell\",\"installs\":[\"FieldtypeNotifications\"],\"autoload\":true,\"created\":1440167712,\"installed\":false,\"configurable\":\"SystemNotificationsConfig.php\",\"file\":\"wire\\/modules\\/System\\/SystemNotifications\\/SystemNotifications.module\",\"core\":true},\"TextformatterMarkdownExtra\":{\"name\":\"TextformatterMarkdownExtra\",\"title\":\"Markdown\\/Parsedown Extra\",\"version\":129,\"versionStr\":\"1.2.9\",\"summary\":\"Markdown extra and Parsedown extra lightweight markup language by Emanuil Rusev, Michel Fortin, John Gruber.\",\"created\":1440167712,\"installed\":false,\"configurable\":true,\"file\":\"wire\\/modules\\/Textformatter\\/TextformatterMarkdownExtra\\/TextformatterMarkdownExtra.module\",\"core\":true},\"TextformatterNewlineBR\":{\"name\":\"TextformatterNewlineBR\",\"title\":\"Newlines to XHTML Line Breaks\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Converts newlines to XHTML line break <br \\/> tags. \",\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/Textformatter\\/TextformatterNewlineBR.module\",\"core\":true},\"TextformatterNewlineUL\":{\"name\":\"TextformatterNewlineUL\",\"title\":\"Newlines to Unordered List\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Converts newlines to <li> list items and surrounds in an <ul> unordered list. \",\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/Textformatter\\/TextformatterNewlineUL.module\",\"core\":true},\"TextformatterPstripper\":{\"name\":\"TextformatterPstripper\",\"title\":\"Paragraph Stripper\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Strips paragraph <p> tags that may have been applied by other text formatters before it. \",\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/Textformatter\\/TextformatterPstripper.module\",\"core\":true},\"TextformatterSmartypants\":{\"name\":\"TextformatterSmartypants\",\"title\":\"SmartyPants Typographer\",\"version\":152,\"versionStr\":\"1.5.2\",\"summary\":\"Smart typography for web sites, by Michel Fortin based on SmartyPants by John Gruber. If combined with Markdown, it should be applied AFTER Markdown.\",\"created\":1440167712,\"installed\":false,\"file\":\"wire\\/modules\\/Textformatter\\/TextformatterSmartypants\\/TextformatterSmartypants.module\",\"core\":true,\"url\":\"http:\\/\\/michelf.com\\/projects\\/php-smartypants\\/typographer\\/\"},\"TextformatterStripTags\":{\"name\":\"TextformatterStripTags\",\"title\":\"Strip Markup Tags\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Strips HTML\\/XHTML Markup Tags\",\"created\":1440167712,\"installed\":false,\"configurable\":true,\"file\":\"wire\\/modules\\/Textformatter\\/TextformatterStripTags.module\",\"core\":true},\"Helloworld\":{\"name\":\"Helloworld\",\"title\":\"Hello World\",\"version\":2,\"versionStr\":\"0.0.2\",\"summary\":\"An example module used for demonstration purposes. See the \\/site\\/modules\\/Helloworld.module file for details.\",\"href\":\"http:\\/\\/processwire.com\",\"icon\":\"smile-o\",\"autoload\":true,\"singular\":true,\"created\":1440527732,\"installed\":false,\"file\":\"site\\/modules\\/Helloworld.module\"}}','2010-04-08 03:10:10'),
	('ModulesVerbose.info','{\"148\":{\"summary\":\"Minimal admin theme that supports all ProcessWire features.\",\"file\":\"wire\\/modules\\/AdminTheme\\/AdminThemeDefault\\/AdminThemeDefault.module\",\"core\":true,\"versionStr\":\"0.1.4\"},\"171\":{\"summary\":\"Admin theme for ProcessWire 2.5+ by Tom Reno (Renobird)\",\"author\":\"Tom Reno (Renobird)\",\"file\":\"wire\\/modules\\/AdminTheme\\/AdminThemeReno\\/AdminThemeReno.module\",\"core\":true,\"versionStr\":\"0.1.7\"},\"97\":{\"summary\":\"This Fieldtype stores an ON\\/OFF toggle via a single checkbox. The ON value is 1 and OFF value is 0.\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeCheckbox.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"28\":{\"summary\":\"Field that stores a date and optionally time\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeDatetime.module\",\"core\":true,\"versionStr\":\"1.0.4\"},\"29\":{\"summary\":\"Field that stores an e-mail address\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeEmail.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"106\":{\"summary\":\"Close a fieldset opened by FieldsetOpen. \",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeFieldsetClose.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"105\":{\"summary\":\"Open a fieldset to group fields. Should be followed by a Fieldset (Close) after one or more fields.\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeFieldsetOpen.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"107\":{\"summary\":\"Open a fieldset to group fields. Same as Fieldset (Open) except that it displays in a tab instead.\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeFieldsetTabOpen.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"6\":{\"summary\":\"Field that stores one or more files\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeFile.module\",\"core\":true,\"versionStr\":\"1.0.4\"},\"89\":{\"summary\":\"Field that stores a floating point (decimal) number\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeFloat.module\",\"core\":true,\"versionStr\":\"1.0.5\"},\"57\":{\"summary\":\"Field that stores one or more GIF, JPG, or PNG images\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeImage.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"84\":{\"summary\":\"Field that stores an integer\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeInteger.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"27\":{\"summary\":\"Field that stores a reference to another module\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeModule.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"4\":{\"summary\":\"Field that stores one or more references to ProcessWire pages\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypePage.module\",\"core\":true,\"versionStr\":\"1.0.2\"},\"177\":{\"summary\":\"A fieldtype containing a group of editable pages.\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypePageTable.module\",\"core\":true,\"versionStr\":\"0.0.8\"},\"111\":{\"summary\":\"Field that stores a page title\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypePageTitle.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"133\":{\"summary\":\"Field that stores a hashed and salted password\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypePassword.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"172\":{\"summary\":\"Maintains a collection of fields that are repeated for any number of times.\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeRepeater\\/FieldtypeRepeater.module\",\"core\":true,\"versionStr\":\"1.0.2\"},\"173\":{\"summary\":\"Repeats fields from another template. Provides the input for FieldtypeRepeater.\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeRepeater\\/InputfieldRepeater.module\",\"core\":true,\"versionStr\":\"1.0.2\"},\"174\":{\"summary\":\"Build a page finding selector visually.\",\"author\":\"Avoine + ProcessWire\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeSelector.module\",\"core\":true,\"versionStr\":\"0.1.3\"},\"3\":{\"summary\":\"Field that stores a single line of text\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeText.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"1\":{\"summary\":\"Field that stores multiple lines of text\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeTextarea.module\",\"core\":true,\"versionStr\":\"1.0.4\"},\"135\":{\"summary\":\"Field that stores a URL\",\"file\":\"wire\\/modules\\/Fieldtype\\/FieldtypeURL.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"25\":{\"summary\":\"Multiple selection, progressive enhancement to select multiple\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldAsmSelect\\/InputfieldAsmSelect.module\",\"core\":true,\"versionStr\":\"1.1.8\"},\"131\":{\"summary\":\"Form button element that you can optionally pass an href attribute to.\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldButton.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"37\":{\"summary\":\"Single checkbox toggle\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldCheckbox.module\",\"core\":true,\"versionStr\":\"1.0.4\"},\"38\":{\"summary\":\"Multiple checkbox toggles\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldCheckboxes\\/InputfieldCheckboxes.module\",\"core\":true,\"versionStr\":\"1.0.7\"},\"155\":{\"summary\":\"CKEditor textarea rich text editor.\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldCKEditor\\/InputfieldCKEditor.module\",\"core\":true,\"versionStr\":\"1.5.3\"},\"94\":{\"summary\":\"Inputfield that accepts date and optionally time\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldDatetime\\/InputfieldDatetime.module\",\"core\":true,\"versionStr\":\"1.0.4\"},\"80\":{\"summary\":\"E-Mail address in valid format\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldEmail.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"78\":{\"summary\":\"Groups one or more fields together in a container\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldFieldset.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"55\":{\"summary\":\"One or more file uploads (sortable)\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldFile\\/InputfieldFile.module\",\"core\":true,\"versionStr\":\"1.2.4\"},\"90\":{\"summary\":\"Floating point number with precision\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldFloat.module\",\"core\":true,\"versionStr\":\"1.0.3\"},\"30\":{\"summary\":\"Contains one or more fields in a form\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldForm.module\",\"core\":true,\"versionStr\":\"1.0.6\"},\"40\":{\"summary\":\"Hidden value in a form\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldHidden.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"170\":{\"summary\":\"Select an icon\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldIcon\\/InputfieldIcon.module\",\"core\":true,\"versionStr\":\"0.0.2\"},\"56\":{\"summary\":\"One or more image uploads (sortable)\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldImage\\/InputfieldImage.module\",\"core\":true,\"versionStr\":\"1.1.6\"},\"85\":{\"summary\":\"Integer (positive or negative)\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldInteger.module\",\"core\":true,\"versionStr\":\"1.0.3\"},\"79\":{\"summary\":\"Contains any other markup and optionally child Inputfields\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldMarkup.module\",\"core\":true,\"versionStr\":\"1.0.2\"},\"41\":{\"summary\":\"Text input validated as a ProcessWire name field\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldName.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"60\":{\"summary\":\"Select one or more pages\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldPage\\/InputfieldPage.module\",\"core\":true,\"versionStr\":\"1.0.6\"},\"15\":{\"summary\":\"Selection of a single page from a ProcessWire page tree list\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldPageListSelect\\/InputfieldPageListSelect.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"137\":{\"summary\":\"Selection of multiple pages from a ProcessWire page tree list\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldPageListSelect\\/InputfieldPageListSelectMultiple.module\",\"core\":true,\"versionStr\":\"1.0.2\"},\"86\":{\"summary\":\"Text input validated as a ProcessWire Page name field\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldPageName\\/InputfieldPageName.module\",\"core\":true,\"versionStr\":\"1.0.6\"},\"178\":{\"summary\":\"Inputfield to accompany FieldtypePageTable\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldPageTable\\/InputfieldPageTable.module\",\"core\":true,\"versionStr\":\"0.1.2\"},\"112\":{\"summary\":\"Handles input of Page Title and auto-generation of Page Name (when name is blank)\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldPageTitle\\/InputfieldPageTitle.module\",\"core\":true,\"versionStr\":\"1.0.2\"},\"122\":{\"summary\":\"Password input with confirmation field that doesn&#039;t ever echo the input back.\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldPassword.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"39\":{\"summary\":\"Radio buttons for selection of a single item\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldRadios\\/InputfieldRadios.module\",\"core\":true,\"versionStr\":\"1.0.5\"},\"36\":{\"summary\":\"Selection of a single value from a select pulldown\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldSelect.module\",\"core\":true,\"versionStr\":\"1.0.2\"},\"43\":{\"summary\":\"Select multiple items from a list\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldSelectMultiple.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"149\":{\"summary\":\"Build a page finding selector visually.\",\"author\":\"Avoine + ProcessWire\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldSelector\\/InputfieldSelector.module\",\"core\":true,\"versionStr\":\"0.2.6\"},\"32\":{\"summary\":\"Form submit button\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldSubmit\\/InputfieldSubmit.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"34\":{\"summary\":\"Single line of text\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldText.module\",\"core\":true,\"versionStr\":\"1.0.5\"},\"35\":{\"summary\":\"Multiple lines of text\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldTextarea.module\",\"core\":true,\"versionStr\":\"1.0.3\"},\"108\":{\"summary\":\"URL in valid format\",\"file\":\"wire\\/modules\\/Inputfield\\/InputfieldURL.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"116\":{\"summary\":\"jQuery Core as required by ProcessWire Admin and plugins\",\"href\":\"http:\\/\\/jquery.com\",\"file\":\"wire\\/modules\\/Jquery\\/JqueryCore\\/JqueryCore.module\",\"core\":true,\"versionStr\":\"1.8.3\"},\"151\":{\"summary\":\"Provides lightbox capability for image galleries. Replacement for FancyBox. Uses Magnific Popup by @dimsemenov.\",\"href\":\"http:\\/\\/dimsemenov.com\\/plugins\\/magnific-popup\\/\",\"file\":\"wire\\/modules\\/Jquery\\/JqueryMagnific\\/JqueryMagnific.module\",\"core\":true,\"versionStr\":\"0.0.1\"},\"103\":{\"summary\":\"Provides a jQuery plugin for sorting tables.\",\"href\":\"http:\\/\\/mottie.github.io\\/tablesorter\\/\",\"file\":\"wire\\/modules\\/Jquery\\/JqueryTableSorter\\/JqueryTableSorter.module\",\"core\":true,\"versionStr\":\"2.2.1\"},\"117\":{\"summary\":\"jQuery UI as required by ProcessWire and plugins\",\"href\":\"http:\\/\\/ui.jquery.com\",\"file\":\"wire\\/modules\\/Jquery\\/JqueryUI\\/JqueryUI.module\",\"core\":true,\"versionStr\":\"1.9.6\"},\"45\":{\"summary\":\"Provides a jQuery plugin for generating tabs in ProcessWire.\",\"file\":\"wire\\/modules\\/Jquery\\/JqueryWireTabs\\/JqueryWireTabs.module\",\"core\":true,\"versionStr\":\"1.0.7\"},\"163\":{\"summary\":\"Field that stores a page title in multiple languages. Use this only if you want title inputs created for ALL languages on ALL pages. Otherwise create separate languaged-named title fields, i.e. title_fr, title_es, title_fi, etc. \",\"author\":\"Ryan Cramer\",\"file\":\"wire\\/modules\\/LanguageSupport\\/FieldtypePageTitleLanguage.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"164\":{\"summary\":\"Field that stores a multiple lines of text in multiple languages\",\"file\":\"wire\\/modules\\/LanguageSupport\\/FieldtypeTextareaLanguage.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"162\":{\"summary\":\"Field that stores a single line of text in multiple languages\",\"file\":\"wire\\/modules\\/LanguageSupport\\/FieldtypeTextLanguage.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"158\":{\"summary\":\"ProcessWire multi-language support.\",\"author\":\"Ryan Cramer\",\"file\":\"wire\\/modules\\/LanguageSupport\\/LanguageSupport.module\",\"core\":true,\"versionStr\":\"1.0.3\"},\"161\":{\"summary\":\"Required to use multi-language fields.\",\"author\":\"Ryan Cramer\",\"file\":\"wire\\/modules\\/LanguageSupport\\/LanguageSupportFields.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"165\":{\"summary\":\"Required to use multi-language page names.\",\"author\":\"Ryan Cramer\",\"file\":\"wire\\/modules\\/LanguageSupport\\/LanguageSupportPageNames.module\",\"core\":true,\"versionStr\":\"0.0.9\"},\"166\":{\"summary\":\"Organizes multi-language fields into tabs for a cleaner easier to use interface.\",\"author\":\"adamspruijt, ryan\",\"file\":\"wire\\/modules\\/LanguageSupport\\/LanguageTabs.module\",\"core\":true,\"versionStr\":\"1.1.3\"},\"159\":{\"summary\":\"Manage system languages\",\"author\":\"Ryan Cramer\",\"file\":\"wire\\/modules\\/LanguageSupport\\/ProcessLanguage.module\",\"core\":true,\"versionStr\":\"1.0.2\"},\"160\":{\"summary\":\"Provides language translation capabilities for ProcessWire core and modules.\",\"author\":\"Ryan Cramer\",\"file\":\"wire\\/modules\\/LanguageSupport\\/ProcessLanguageTranslator.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"67\":{\"summary\":\"Generates markup for data tables used by ProcessWire admin\",\"file\":\"wire\\/modules\\/Markup\\/MarkupAdminDataTable\\/MarkupAdminDataTable.module\",\"core\":true,\"versionStr\":\"1.0.7\"},\"156\":{\"summary\":\"Front-end to the HTML Purifier library.\",\"file\":\"wire\\/modules\\/Markup\\/MarkupHTMLPurifier\\/MarkupHTMLPurifier.module\",\"core\":true,\"versionStr\":\"1.0.4\"},\"113\":{\"summary\":\"Adds a render() method to all PageArray instances for basic unordered list generation of PageArrays.\",\"file\":\"wire\\/modules\\/Markup\\/MarkupPageArray.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"98\":{\"summary\":\"Generates markup for pagination navigation\",\"file\":\"wire\\/modules\\/Markup\\/MarkupPagerNav\\/MarkupPagerNav.module\",\"core\":true,\"versionStr\":\"1.0.3\"},\"152\":{\"summary\":\"Keeps track of past URLs where pages have lived and automatically redirects (301 permament) to the new location whenever the past URL is accessed.\",\"file\":\"wire\\/modules\\/PagePathHistory.module\",\"core\":true,\"versionStr\":\"0.0.1\"},\"114\":{\"summary\":\"Adds various permission methods to Page objects that are used by Process modules.\",\"file\":\"wire\\/modules\\/PagePermissions.module\",\"core\":true,\"versionStr\":\"1.0.5\"},\"115\":{\"summary\":\"Adds a render method to Page and caches page output.\",\"file\":\"wire\\/modules\\/PageRender.module\",\"core\":true,\"versionStr\":\"1.0.3\"},\"48\":{\"summary\":\"Edit individual fields that hold page data\",\"file\":\"wire\\/modules\\/Process\\/ProcessField\\/ProcessField.module\",\"core\":true,\"versionStr\":\"1.1.1\"},\"176\":{\"summary\":\"Provides password reset\\/email capability for the Login process.\",\"file\":\"wire\\/modules\\/Process\\/ProcessForgotPassword.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"87\":{\"summary\":\"Acts as a placeholder Process for the admin root. Ensures proper flow control after login.\",\"file\":\"wire\\/modules\\/Process\\/ProcessHome.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"76\":{\"summary\":\"Lists the Process assigned to each child page of the current\",\"file\":\"wire\\/modules\\/Process\\/ProcessList.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"169\":{\"summary\":\"View and manage system logs.\",\"author\":\"Ryan Cramer\",\"file\":\"wire\\/modules\\/Process\\/ProcessLogger\\/ProcessLogger.module\",\"core\":true,\"versionStr\":\"0.0.1\",\"permissions\":{\"logs-view\":\"Can view system logs\",\"logs-edit\":\"Can manage system logs\"},\"page\":{\"name\":\"logs\",\"parent\":\"setup\",\"title\":\"Logs\"}},\"10\":{\"summary\":\"Login to ProcessWire\",\"file\":\"wire\\/modules\\/Process\\/ProcessLogin\\/ProcessLogin.module\",\"core\":true,\"versionStr\":\"1.0.3\"},\"50\":{\"summary\":\"List, edit or install\\/uninstall modules\",\"file\":\"wire\\/modules\\/Process\\/ProcessModule\\/ProcessModule.module\",\"core\":true,\"versionStr\":\"1.1.8\"},\"17\":{\"summary\":\"Add a new page\",\"file\":\"wire\\/modules\\/Process\\/ProcessPageAdd\\/ProcessPageAdd.module\",\"core\":true,\"versionStr\":\"1.0.8\"},\"7\":{\"summary\":\"Edit a Page\",\"file\":\"wire\\/modules\\/Process\\/ProcessPageEdit\\/ProcessPageEdit.module\",\"core\":true,\"versionStr\":\"1.0.8\"},\"129\":{\"summary\":\"Provides an image select capability as used by some Fieldtype modules (like TinyMCE)\",\"file\":\"wire\\/modules\\/Process\\/ProcessPageEditImageSelect\\/ProcessPageEditImageSelect.module\",\"core\":true,\"versionStr\":\"1.1.9\"},\"121\":{\"summary\":\"Provides a link capability as used by some Fieldtype modules (like rich text editors).\",\"file\":\"wire\\/modules\\/Process\\/ProcessPageEditLink\\/ProcessPageEditLink.module\",\"core\":true,\"versionStr\":\"1.0.8\"},\"12\":{\"summary\":\"List pages in a hierarchal tree structure\",\"file\":\"wire\\/modules\\/Process\\/ProcessPageList\\/ProcessPageList.module\",\"core\":true,\"versionStr\":\"1.1.7\"},\"150\":{\"summary\":\"Admin tool for finding and listing pages by any property.\",\"author\":\"Ryan Cramer\",\"file\":\"wire\\/modules\\/Process\\/ProcessPageLister\\/ProcessPageLister.module\",\"core\":true,\"versionStr\":\"0.2.4\",\"permissions\":{\"page-lister\":\"Use Page Lister\"}},\"104\":{\"summary\":\"Provides a page search engine for admin use.\",\"file\":\"wire\\/modules\\/Process\\/ProcessPageSearch\\/ProcessPageSearch.module\",\"core\":true,\"versionStr\":\"1.0.6\"},\"14\":{\"summary\":\"Handles page sorting and moving for PageList\",\"file\":\"wire\\/modules\\/Process\\/ProcessPageSort.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"109\":{\"summary\":\"Handles emptying of Page trash\",\"file\":\"wire\\/modules\\/Process\\/ProcessPageTrash.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"134\":{\"summary\":\"List, Edit and Add pages of a specific type\",\"file\":\"wire\\/modules\\/Process\\/ProcessPageType\\/ProcessPageType.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"83\":{\"summary\":\"All page views are routed through this Process\",\"file\":\"wire\\/modules\\/Process\\/ProcessPageView.module\",\"core\":true,\"versionStr\":\"1.0.3\"},\"136\":{\"summary\":\"Manage system permissions\",\"file\":\"wire\\/modules\\/Process\\/ProcessPermission\\/ProcessPermission.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"138\":{\"summary\":\"Enables user to change their password, email address and other settings that you define.\",\"file\":\"wire\\/modules\\/Process\\/ProcessProfile\\/ProcessProfile.module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"168\":{\"summary\":\"Shows a list of recently edited pages in your admin.\",\"author\":\"Ryan Cramer\",\"href\":\"http:\\/\\/modules.processwire.com\\/\",\"file\":\"wire\\/modules\\/Process\\/ProcessRecentPages\\/ProcessRecentPages.module\",\"core\":true,\"versionStr\":\"0.0.2\",\"permissions\":{\"page-edit-recent\":\"Can see recently edited pages\"},\"page\":{\"name\":\"recent-pages\",\"parent\":\"page\",\"title\":\"Recent\"}},\"68\":{\"summary\":\"Manage user roles and what permissions are attached\",\"file\":\"wire\\/modules\\/Process\\/ProcessRole\\/ProcessRole.module\",\"core\":true,\"versionStr\":\"1.0.2\"},\"47\":{\"summary\":\"List and edit the templates that control page output\",\"file\":\"wire\\/modules\\/Process\\/ProcessTemplate\\/ProcessTemplate.module\",\"core\":true,\"versionStr\":\"1.1.3\"},\"66\":{\"summary\":\"Manage system users\",\"file\":\"wire\\/modules\\/Process\\/ProcessUser\\/ProcessUser.module\",\"core\":true,\"versionStr\":\"1.0.6\"},\"125\":{\"summary\":\"Throttles the frequency of logins for a given account, helps to reduce dictionary attacks by introducing an exponential delay between logins.\",\"file\":\"wire\\/modules\\/Session\\/SessionLoginThrottle\\/SessionLoginThrottle.module\",\"core\":true,\"versionStr\":\"1.0.2\"},\"139\":{\"summary\":\"Manages system versions and upgrades.\",\"file\":\"wire\\/modules\\/System\\/SystemUpdater\\/SystemUpdater.module\",\"core\":true,\"versionStr\":\"0.1.1\"},\"61\":{\"summary\":\"Entity encode ampersands, quotes (single and double) and greater-than\\/less-than signs using htmlspecialchars(str, ENT_QUOTES). It is recommended that you use this on all text\\/textarea fields except those using a rich text editor like TinyMCE or a markup language like Markdown.\",\"file\":\"wire\\/modules\\/Textformatter\\/TextformatterEntities.module\",\"core\":true,\"versionStr\":\"1.0.0\"},\"175\":{\"summary\":\"Redirects ID based URL to full SEO friendly URL\",\"href\":\"http:\\/\\/modules.processwire.com\\/modules\\/process-redirect-ids\\/\",\"file\":\"site\\/modules\\/ProcessRedirectIds\\/ProcessRedirectIds.module\",\"versionStr\":\"0.2.9\"},\"179\":{\"summary\":\"Save a short version of the summary content as title of a question page\",\"file\":\"site\\/modules\\/GenerateQuestionShortTitle.module\",\"versionStr\":\"0.0.1\"}}','2010-04-08 03:10:10'),
	('Modules.site/modules/','GenerateQuestionShortTitle.module\nHelloworld.module\nProcessRedirectIds/ProcessRedirectIds.module','2010-04-08 03:10:10');

/*!40000 ALTER TABLE `caches` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_admin_theme
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_admin_theme`;

CREATE TABLE `field_admin_theme` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_admin_theme` WRITE;
/*!40000 ALTER TABLE `field_admin_theme` DISABLE KEYS */;

INSERT INTO `field_admin_theme` (`pages_id`, `data`)
VALUES
	(41,171),
	(40,171);

/*!40000 ALTER TABLE `field_admin_theme` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_answers
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_answers`;

CREATE TABLE `field_answers` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `count` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(1)),
  KEY `count` (`count`,`pages_id`),
  KEY `parent_id` (`parent_id`,`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_answers` WRITE;
/*!40000 ALTER TABLE `field_answers` DISABLE KEYS */;

INSERT INTO `field_answers` (`pages_id`, `data`, `count`, `parent_id`)
VALUES
	(1222,'1224,1225,1226,1227',4,1223),
	(1232,'1234,1235',2,1233),
	(1241,'1243,1244',2,1242);

/*!40000 ALTER TABLE `field_answers` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_body
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_body`;

CREATE TABLE `field_body` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  `data1013` mediumtext,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1013` (`data1013`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_body` WRITE;
/*!40000 ALTER TABLE `field_body` DISABLE KEYS */;

INSERT INTO `field_body` (`pages_id`, `data`, `data1013`)
VALUES
	(27,'<h3>The page you were looking for is not found.</h3>\n\n<p>Please use our search engine or navigation above to find the page.</p>','<h3>Sivu etsit ei löytynyt.</h3>\n\n<p>Ole hyvä ja käytä hakukonetta tai navigointi ennen löytää sivun.</p>'),
	(1,'<h2>What is ProcessWire?</h2>\n\n<p>ProcessWire gives you full control over your fields, templates and markup. It provides a powerful template system that works the way you do. Not to mention, ProcessWire\'s API makes working with your content easy and enjoyable. <a href=\"http://processwire.com\">Learn more</a></p>\n\n<h3>About this site profile</h3>\n\n<p>This is a basic minimal site for you to use in developing your own site or to learn from. There are a few pages here to serve as examples, but this site profile does not make any attempt to demonstrate all that ProcessWire can do. To learn more or ask questions, visit the <a href=\"http://www.processwire.com/talk/\" target=\"_blank\">ProcessWire forums</a> or <a href=\"http://modules.processwire.com/categories/site-profile/\">browse more site profiles</a>. If you are building a new site, this minimal profile is a good place to start. You may use these existing templates and design as they are, or you may replace them entirely.</p>\n\n<h3>Browse the site</h3>','<h2>Mikä on ProcessWire?</h2>\n\n<p>ProcessWire antaa sinulle täyden kontrollin kentät, malleja ja markup. Se tarjoaa tehokkaan mallin, joka toimii niin teet. Puhumattakaan, ProcessWire API tekee työskentelystä sisällön helppoa ja nautinnollista. <a href=\"http://fi.processwire.com\">Lue lisää</a></p>\n\n<h3>Tietoa palvelusta profiili</h3>\n\n<p>Tämä on perus minimaalinen sivuston voit käyttää kehittämään oman sivuston tai oppia. On olemassa muutamia sivuja tänne esimerkeiksi, mutta tämä sivusto profiilia ei tee mitään yrittäneet osoittaa kaikille, että ProcessWire voi tehdä. Jos rakennat uuden sivuston, tämä minimaalinen profiili on hyvä paikka aloittaa. Voit käyttää näitä olemassa olevia malleja ja suunnittelun kuin ne ovat, tai voit korvata ne kokonaan.</p>\n\n<h3>Selata sivustoa</h3>'),
	(1002,'<h2>Ut capio feugiat saepius torqueo olim</h2>\n\n<h3>In utinam facilisi eum vicis feugait nimis</h3>\n\n<p>Iusto incassum appellatio cui macto genitus vel. Lobortis aliquam luctus, roto enim, imputo wisi tamen. Ratis odio, genitus acsi, neo illum consequat consectetuer ut.</p>\n\n<blockquote>\n<p>Wisi fere virtus cogo, ex ut vel nullus similis vel iusto. Tation incassum adsum in, quibus capto premo diam suscipere facilisi. Uxor laoreet mos capio premo feugait ille et. Pecus abigo immitto epulae duis vel. Neque causa, indoles verto, decet ingenium dignissim.</p>\n</blockquote>\n\n<p>Patria iriure vel vel autem proprius indoles ille sit. Tation blandit refoveo, accumsan ut ulciscor lucidus inhibeo capto aptent opes, foras.</p>\n\n<h3>Dolore ea valde refero feugait utinam luctus</h3>\n\n<p>Usitas, nostrud transverbero, in, amet, nostrud ad. Ex feugiat opto diam os aliquam regula lobortis dolore ut ut quadrum. Esse eu quis nunc jugis iriure volutpat wisi, fere blandit inhibeo melior, hendrerit, saluto velit. Eu bene ideo dignissim delenit accumsan nunc. Usitas ille autem camur consequat typicus feugait elit ex accumsan nutus accumsan nimis pagus, occuro. Immitto populus, qui feugiat opto pneum letalis paratus. Mara conventio torqueo nibh caecus abigo sit eum brevitas. Populus, duis ex quae exerci hendrerit, si antehabeo nobis, consequat ea praemitto zelus.</p>\n\n<p>Immitto os ratis euismod conventio erat jus caecus sudo. code test Appellatio consequat, et ibidem ludus nulla dolor augue abdo tego euismod plaga lenis. Sit at nimis venio venio tego os et pecus enim pneum magna nobis ad pneum. Saepius turpis probo refero molior nonummy aliquam neque appellatio jus luctus acsi. Ulciscor refero pagus imputo eu refoveo valetudo duis dolore usitas. Consequat suscipere quod torqueo ratis ullamcorper, dolore lenis, letalis quia quadrum plaga minim.</p>',''),
	(1001,'<h2>Si lobortis singularis genitus ibidem saluto.</h2>\n\n<p>Dolore ad nunc, mos accumsan paratus duis suscipit luptatum facilisis macto uxor iaceo quadrum. Demoveo, appellatio elit neque ad commodo ea. Wisi, iaceo, tincidunt at commoveo rusticus et, ludus. Feugait at blandit bene blandit suscipere abdo duis ideo bis commoveo pagus ex, velit. Consequat commodo roto accumsan, duis transverbero.</p>','<h2>Jos yksittäisten politiikkojen syntyy siellä vierailla.</h2>\n\n<p>Kipu nyt, asiakaslähtöinen joukkue valmis suorittamaan dynaamisia OpenCms Japani wife\'ve neliö. Peruttiin, valitus on ympäristölle tai hyödyntää näitä asioita. Kaikki mitä tarvitset on: Olen, jonka tavoitteena on maalaismainen, nyt liikkua, peli. Feugait mutta tutkijat ottaa iltapäivän hyvin Abdo n kahdesti nyt muuttamaan pois kylästä, kiitos. Resepti, ota kiertää kerros, elokuva Drive.</p>'),
	(1004,'<h2>Pertineo vel dignissim, natu letalis fere odio</h2>\n\n<p>Magna in gemino, gilvus iusto capto jugis abdo mos aptent acsi qui. Utrum inhibeo humo humo duis quae. Lucidus paulatim facilisi scisco quibus hendrerit conventio adsum.</p>\n\n<h3>Si lobortis singularis genitus ibidem saluto</h3>\n\n<ul><li>Feugiat eligo foras ex elit sed indoles hos elit ex antehabeo defui et nostrud.</li>\n	<li>Letatio valetudo multo consequat inhibeo ille dignissim pagus et in quadrum eum eu.</li>\n	<li>Aliquam si consequat, ut nulla amet et turpis exerci, adsum luctus ne decet, delenit.</li>\n	<li>Commoveo nunc diam valetudo cui, aptent commoveo at obruo uxor nulla aliquip augue.</li>\n</ul><p>Iriure, ex velit, praesent vulpes delenit capio vero gilvus inhibeo letatio aliquip metuo qui eros. Transverbero demoveo euismod letatio torqueo melior. Ut odio in suscipit paulatim amet huic letalis suscipere eros causa, letalis magna.</p>\n\n<ol><li>Feugiat eligo foras ex elit sed indoles hos elit ex antehabeo defui et nostrud.</li>\n	<li>Letatio valetudo multo consequat inhibeo ille dignissim pagus et in quadrum eum eu.</li>\n	<li>Aliquam si consequat, ut nulla amet et turpis exerci, adsum luctus ne decet, delenit.</li>\n	<li>Commoveo nunc diam valetudo cui, aptent commoveo at obruo uxor nulla aliquip augue.</li>\n</ol>',''),
	(1020,'','');

/*!40000 ALTER TABLE `field_body` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_email
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_email`;

CREATE TABLE `field_email` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_email` WRITE;
/*!40000 ALTER TABLE `field_email` DISABLE KEYS */;

INSERT INTO `field_email` (`pages_id`, `data`)
VALUES
	(41,'sergio@plasmadesign.com.br');

/*!40000 ALTER TABLE `field_email` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_headline
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_headline`;

CREATE TABLE `field_headline` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1013` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1013` (`data1013`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1013` (`data1013`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_headline` WRITE;
/*!40000 ALTER TABLE `field_headline` DISABLE KEYS */;

INSERT INTO `field_headline` (`pages_id`, `data`, `data1013`)
VALUES
	(1,'Minimal Site Profile','Vähäinen Sivusto Esimerkiksi');

/*!40000 ALTER TABLE `field_headline` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_images
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_images`;

CREATE TABLE `field_images` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_images` WRITE;
/*!40000 ALTER TABLE `field_images` DISABLE KEYS */;

INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`)
VALUES
	(1,'bigger-terminal.jpg',0,'{\"0\":\"We\'re gonna need a bigger terminal.\",\"1012\":\"Wir brauchen einen größeren Terminal.\",\"1013\":\"Me tarvitsemme isomman päätteen.\"}','2014-09-02 11:13:06','2014-09-02 11:11:35'),
	(1,'design-team.jpg',1,'{\"0\":\"You know, there are better ways to manage a design team.\",\"1012\":\"Wissen Si, es gibt bessere Möglichkeiten, ein Design-Team zu leiten.\",\"1013\":\"Te tiedätte, on olemassa parempia tapoja hallita suunnittelutiimi.\"}','2014-09-02 11:13:06','2014-09-02 11:11:35');

/*!40000 ALTER TABLE `field_images` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_is_correct
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_is_correct`;

CREATE TABLE `field_is_correct` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` tinyint(4) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_is_correct` WRITE;
/*!40000 ALTER TABLE `field_is_correct` DISABLE KEYS */;

INSERT INTO `field_is_correct` (`pages_id`, `data`)
VALUES
	(1224,1),
	(1235,1),
	(1243,1);

/*!40000 ALTER TABLE `field_is_correct` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_language
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_language`;

CREATE TABLE `field_language` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_language` WRITE;
/*!40000 ALTER TABLE `field_language` DISABLE KEYS */;

INSERT INTO `field_language` (`pages_id`, `data`, `sort`)
VALUES
	(40,1010,0),
	(41,1010,0);

/*!40000 ALTER TABLE `field_language` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_language_files
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_language_files`;

CREATE TABLE `field_language_files` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table field_language_files_site
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_language_files_site`;

CREATE TABLE `field_language_files_site` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table field_pass
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_pass`;

CREATE TABLE `field_pass` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` char(40) NOT NULL,
  `salt` char(32) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=ascii;

LOCK TABLES `field_pass` WRITE;
/*!40000 ALTER TABLE `field_pass` DISABLE KEYS */;

INSERT INTO `field_pass` (`pages_id`, `data`, `salt`)
VALUES
	(41,'5p8OuFy5lRwx0ISkTDoTt9yK8D7q3Di','$2y$11$5FFwYM9tQK.KIPXXuFOSze'),
	(40,'','');

/*!40000 ALTER TABLE `field_pass` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_permissions`;

CREATE TABLE `field_permissions` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_permissions` WRITE;
/*!40000 ALTER TABLE `field_permissions` DISABLE KEYS */;

INSERT INTO `field_permissions` (`pages_id`, `data`, `sort`)
VALUES
	(38,32,1),
	(38,34,2),
	(38,35,3),
	(37,36,0),
	(38,36,0),
	(38,50,4),
	(38,51,5),
	(38,52,7),
	(38,53,8),
	(38,54,6);

/*!40000 ALTER TABLE `field_permissions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_process
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_process`;

CREATE TABLE `field_process` (
  `pages_id` int(11) NOT NULL DEFAULT '0',
  `data` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_process` WRITE;
/*!40000 ALTER TABLE `field_process` DISABLE KEYS */;

INSERT INTO `field_process` (`pages_id`, `data`)
VALUES
	(6,17),
	(3,12),
	(8,12),
	(9,14),
	(10,7),
	(11,47),
	(16,48),
	(300,104),
	(21,50),
	(29,66),
	(23,10),
	(304,138),
	(31,136),
	(22,76),
	(30,68),
	(303,129),
	(2,87),
	(302,121),
	(301,109),
	(28,76),
	(1007,150),
	(1009,159),
	(1011,160),
	(1015,168),
	(1017,169);

/*!40000 ALTER TABLE `field_process` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_question_title
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_question_title`;

CREATE TABLE `field_question_title` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  `data1013` mediumtext,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1013` (`data1013`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_question_title` WRITE;
/*!40000 ALTER TABLE `field_question_title` DISABLE KEYS */;

INSERT INTO `field_question_title` (`pages_id`, `data`, `data1013`)
VALUES
	(1222,'Você é o gerente de projeto para um projeto de construção de ferrovias. Seu patrocinador pediu-lhe para uma previsão para o custo de conclusão do projeto. O projecto tem um orçamento total de $80.000 e CPI de 0,95. O projeto passou $25.000 do seu orçamento até agora. Quanto mais dinheiro você pretende gastar no projeto?','You are the project manager for a railroad construction project. Your sponsor has asked you for a forecast for the cost of project completion. The project has a total budget of $80,000 and CPI of .95. The project has spent $25,000 of its budget so far. How much more money do you plan to spend on the project?'),
	(1232,'Qual das seguintes NÃO é uma fonte de informações sobre restrições e premissas específicas do projeto?',''),
	(1241,'Um gerente de projeto está trabalhando em um país onde costuma-se pagar a polícia para serviços de proteção privada. Supervisor do gerente do projeto diz que em outro país, que seria considerada um suborno. Qual é a melhor maneira para o gerente de projeto para prosseguir?','A project manager is working in a country where it is customary to pay the police for private protection services. The project manager’s supervisor tells him that in another country, that would be considered a bribe. What is the BEST way for the project manager to proceed?');

/*!40000 ALTER TABLE `field_question_title` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_roles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_roles`;

CREATE TABLE `field_roles` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_roles` WRITE;
/*!40000 ALTER TABLE `field_roles` DISABLE KEYS */;

INSERT INTO `field_roles` (`pages_id`, `data`, `sort`)
VALUES
	(40,37,0),
	(41,37,0),
	(41,38,2);

/*!40000 ALTER TABLE `field_roles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_sidebar
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_sidebar`;

CREATE TABLE `field_sidebar` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  `data1013` mediumtext,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1013` (`data1013`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_sidebar` WRITE;
/*!40000 ALTER TABLE `field_sidebar` DISABLE KEYS */;

INSERT INTO `field_sidebar` (`pages_id`, `data`, `data1013`)
VALUES
	(1,'<h3>About ProcessWire</h3>\n\n<p>ProcessWire is an open source CMS and web application framework aimed at the needs of designers, developers and their clients.</p>\n\n<ul><li><a href=\"http://processwire.com/talk/\">Support</a></li>\n	<li><a href=\"http://processwire.com/docs/\">Documentation</a></li>\n	<li><a href=\"http://processwire.com/docs/tutorials/\">Tutorials</a></li>\n	<li><a href=\"http://cheatsheet.processwire.com/\">API Cheatsheet</a></li>\n	<li><a href=\"http://modules.processwire.com/\">Modules/Plugins</a></li>\n</ul>','<h3>Tietoja ProcessWire</h3>\n\n<p>ProcessWire on avoimen lähdekoodin CMS ja web-sovellus kehys, jolla pyritään tarpeisiin suunnittelijat, kehittäjät ja niiden asiakkaille.</p>\n\n<ul><li><a href=\"http://processwire.com/talk/\">Tuki</a></li>\n	<li><a href=\"http://processwire.com/docs/\">Dokumentointi</a></li>\n	<li><a href=\"http://processwire.com/docs/tutorials/\">Oppaat</a></li>\n	<li><a href=\"http://cheatsheet.processwire.com/\">API Cheatsheet</a></li>\n	<li><a href=\"http://modules.processwire.com/\">Moduulit / plugins</a></li>\n</ul>'),
	(1002,'<h3>Sudo nullus</h3>\n\n<p>Et torqueo vulpes vereor luctus augue quod consectetuer antehabeo causa patria tation ex plaga ut. Abluo delenit wisi iriure eros feugiat probo nisl aliquip nisl, patria. Antehabeo esse camur nisl modo utinam. Sudo nullus ventosus ibidem facilisis saepius eum sino pneum, vicis odio voco opto.</p>',''),
	(1020,'','');

/*!40000 ALTER TABLE `field_sidebar` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_summary
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_summary`;

CREATE TABLE `field_summary` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  `data1013` mediumtext,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1013` (`data1013`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_summary` WRITE;
/*!40000 ALTER TABLE `field_summary` DISABLE KEYS */;

INSERT INTO `field_summary` (`pages_id`, `data`, `data1013`)
VALUES
	(1002,'Dolore ea valde refero feugait utinam luctus. Probo velit commoveo et, delenit praesent, suscipit zelus, hendrerit zelus illum facilisi, regula. ',''),
	(1001,'This is a placeholder page with two child pages to serve as an example. ','Tämä on paikkamerkki sivulle, jossa on kaksi lasta sivua toimimaan esimerkkinä.'),
	(1005,'View this template\'s source for a demonstration of how to create a basic site map. ','Näytä tämä malli n lähde osoitus siitä, miten luoda perus-sivuston kartta.'),
	(1004,'Mos erat reprobo in praesent, mara premo, obruo iustum pecus velit lobortis te sagaciter populus.',''),
	(1,'ProcessWire is an open source CMS and web application framework aimed at the needs of designers, developers and their clients. ','ProcessWire on avoimen lähdekoodin CMS ja web-sovellus kehys, jolla pyritään tarpeisiin suunnittelijat, kehittäjät ja niiden asiakkaille.'),
	(1020,'',''),
	(1212,'',''),
	(1214,'O que é o PMBOK?',''),
	(1183,'Qual das seguintes NÃO é uma fonte de informações sobre restrições e premissas específicas do projeto?',''),
	(1189,'',''),
	(1195,'You are the project manager for a railroad construction project. Your sponsor has asked you for a forecast for the cost of project completion. The project has a total budget of $\\$$80,000 and CPI of .95. The project has spent $\\$$25,000 of its budget so far. How much more money do you plan to spend on the project?',''),
	(1201,'Você é o gerente de projeto para um projeto de construção de ferrovias. Seu patrocinador pediu-lhe para uma previsão para o custo de conclusão do projeto. O projecto tem um orçamento total de $80.000 e CPI de 0,95. O projeto passou $25.000 do seu orçamento até agora. Quanto mais dinheiro você pretende gastar no projeto?','You are the project manager for a railroad construction project. Your sponsor has asked you for a forecast for the cost of project completion. The project has a total budget of $80,000 and CPI of .95. The project has spent\n$25,000 of its budget so far. How much more money do you plan to spend on the project?');

/*!40000 ALTER TABLE `field_summary` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table field_title
# ------------------------------------------------------------

DROP TABLE IF EXISTS `field_title`;

CREATE TABLE `field_title` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1013` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1013` (`data1013`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1013` (`data1013`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `field_title` WRITE;
/*!40000 ALTER TABLE `field_title` DISABLE KEYS */;

INSERT INTO `field_title` (`pages_id`, `data`, `data1013`)
VALUES
	(11,'Templates',''),
	(16,'Fields',''),
	(22,'Setup',''),
	(3,'Pages',''),
	(6,'Add Page',''),
	(8,'Tree',''),
	(9,'Save Sort',''),
	(10,'Edit Page',''),
	(21,'Modules',''),
	(29,'Users',''),
	(30,'Roles',''),
	(2,'Admin',''),
	(7,'Trash',''),
	(27,'404 Page','404 Sivu'),
	(302,'Insert Link',''),
	(23,'Login',''),
	(304,'Profile',''),
	(301,'Empty Trash',''),
	(300,'Search',''),
	(303,'Insert Image',''),
	(28,'Access',''),
	(31,'Permissions',''),
	(32,'Edit pages',''),
	(34,'Delete pages',''),
	(35,'Move pages (change parent)',''),
	(36,'View pages',''),
	(50,'Sort child pages',''),
	(51,'Change templates on pages',''),
	(52,'Administer users',''),
	(53,'User can update profile/password',''),
	(54,'Lock or unlock a page',''),
	(1,'Home','Koti'),
	(1001,'About','Tietoja'),
	(1002,'Child page example 1','Alasivu esimerkki 1'),
	(1000,'Search','Haku'),
	(1004,'Child page example 2','Alasivu esimerkki 2'),
	(1005,'Site Map','Sivukartta'),
	(1006,'Use Page Lister',''),
	(1007,'Find',''),
	(1009,'Languages',''),
	(1010,'Português','Portuguese'),
	(1011,'Language Translator',''),
	(1013,'Inglês','English'),
	(1015,'Recent',''),
	(1016,'Can see recently edited pages',''),
	(1017,'Logs',''),
	(1018,'Can view system logs',''),
	(1019,'Can manage system logs',''),
	(1020,'Banco de Questões','Question Bank'),
	(1021,'Repeaters',''),
	(1022,'answer',''),
	(1248,'',''),
	(1247,'',''),
	(1230,'',''),
	(1231,'',''),
	(1232,'Qual das seguintes NÃO é uma fonte de informações sobre restrições e premissas específicas do projeto?',''),
	(1233,'no-title',''),
	(1234,'O PMBOK é muito legal',''),
	(1235,'Os riscos devem ser ignorados',''),
	(1237,'',''),
	(1238,'',''),
	(1239,'',''),
	(1240,'',''),
	(1241,'Um gerente de projeto está trabalhando em um país onde costuma-se pagar a polícia para serviços de proteção privada. Supervisor do ger...',''),
	(1242,'no-title',''),
	(1243,'Não pagar o suborno à polícia','Do not pay the police for private protection services, because that would be a bribe B. Ask'),
	(1244,'Pedir ajuda ao supervisor','Ask the supervisor for guidance'),
	(1245,'',''),
	(1246,'',''),
	(1229,'',''),
	(1222,'Você é o gerente de projeto para um projeto de construção de ferrovias. Seu patrocinador pediu-lhe para uma previsão para o custo de co...',''),
	(1223,'no-title',''),
	(1224,'$10.800','Yes'),
	(1225,'$5.000','No'),
	(1226,'$500',''),
	(1227,'Não quero gastar nada a mais',''),
	(1228,'',''),
	(1069,'Digite o título da questão.',''),
	(1070,'Questão de ID = 0','');

/*!40000 ALTER TABLE `field_title` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table fieldgroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fieldgroups`;

CREATE TABLE `fieldgroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET ascii NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;

INSERT INTO `fieldgroups` (`id`, `name`)
VALUES
	(2,'admin'),
	(3,'user'),
	(4,'role'),
	(5,'permission'),
	(1,'home'),
	(88,'sitemap'),
	(83,'basic-page'),
	(80,'search'),
	(97,'language'),
	(98,'question'),
	(99,'repeater_answer'),
	(100,'question-bank');

/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table fieldgroups_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fieldgroups_fields`;

CREATE TABLE `fieldgroups_fields` (
  `fieldgroups_id` int(10) unsigned NOT NULL DEFAULT '0',
  `fields_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(11) unsigned NOT NULL DEFAULT '0',
  `data` text,
  PRIMARY KEY (`fieldgroups_id`,`fields_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `fieldgroups_fields` WRITE;
/*!40000 ALTER TABLE `fieldgroups_fields` DISABLE KEYS */;

INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`)
VALUES
	(2,2,1,NULL),
	(2,1,0,NULL),
	(3,98,3,NULL),
	(3,4,2,NULL),
	(4,5,0,NULL),
	(5,1,0,NULL),
	(3,92,1,NULL),
	(1,44,5,NULL),
	(1,82,4,NULL),
	(80,1,0,NULL),
	(83,82,3,NULL),
	(83,76,2,NULL),
	(1,79,2,NULL),
	(88,1,0,NULL),
	(1,76,3,NULL),
	(88,79,1,NULL),
	(83,44,4,NULL),
	(83,79,1,NULL),
	(97,100,1,NULL),
	(3,3,0,NULL),
	(83,1,0,NULL),
	(97,97,2,NULL),
	(97,1,0,NULL),
	(1,1,0,NULL),
	(1,78,1,NULL),
	(3,103,4,NULL),
	(98,107,0,NULL),
	(98,1,1,'{\"collapsed\":\"4\",\"label\":\"T\\u00edtulo resumido (gerado automaticamente)\",\"label1013\":\"Short title (for lists)\"}'),
	(98,104,2,NULL),
	(98,44,3,NULL),
	(100,76,2,NULL),
	(100,79,1,NULL),
	(100,1,0,NULL),
	(100,82,3,NULL),
	(100,44,4,NULL),
	(99,1,0,NULL),
	(99,105,1,NULL);

/*!40000 ALTER TABLE `fieldgroups_fields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fields`;

CREATE TABLE `fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(128) CHARACTER SET ascii NOT NULL,
  `name` varchar(255) CHARACTER SET ascii NOT NULL,
  `flags` int(11) NOT NULL DEFAULT '0',
  `label` varchar(255) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;

INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`)
VALUES
	(1,'FieldtypePageTitleLanguage','title',13,'Título','{\"required\":1,\"textformatters\":[\"TextformatterEntities\"],\"size\":0,\"maxlength\":255,\"label1013\":\"Title\",\"langBlankInherit\":0,\"collapsed\":0,\"send_templates\":[2,29,1,43,5,44,46,45,26,34]}'),
	(2,'FieldtypeModule','process',25,'Process','{\"description\":\"The process that is executed on this page. Since this is mostly used by ProcessWire internally, it is recommended that you don\'t change the value of this unless adding your own pages in the admin.\",\"collapsed\":1,\"required\":1,\"moduleTypes\":[\"Process\"],\"permanent\":1}'),
	(3,'FieldtypePassword','pass',24,'Set Password','{\"collapsed\":1,\"size\":50,\"maxlength\":128}'),
	(5,'FieldtypePage','permissions',24,'Permissions','{\"derefAsPage\":0,\"parent_id\":31,\"labelFieldName\":\"title\",\"inputfield\":\"InputfieldCheckboxes\"}'),
	(4,'FieldtypePage','roles',24,'Roles','{\"derefAsPage\":0,\"parent_id\":30,\"labelFieldName\":\"name\",\"inputfield\":\"InputfieldCheckboxes\",\"description\":\"User will inherit the permissions assigned to each role. You may assign multiple roles to a user. When accessing a page, the user will only inherit permissions from the roles that are also assigned to the page\'s template.\"}'),
	(92,'FieldtypeEmail','email',9,'E-Mail Address','{\"size\":70,\"maxlength\":255}'),
	(82,'FieldtypeTextareaLanguage','sidebar',0,'Barra lateral','{\"inputfieldClass\":\"InputfieldCKEditor\",\"rows\":5,\"contentType\":1,\"toolbar\":\"Format, Bold, Italic, -, RemoveFormat\\nNumberedList, BulletedList, -, Blockquote\\nPWLink, Unlink, Anchor\\nPWImage, Table, HorizontalRule, SpecialChar\\nPasteText, PasteFromWord\\nScayt, -, Sourcedialog\",\"inlineMode\":0,\"useACF\":1,\"usePurifier\":1,\"formatTags\":\"p;h2;h3;h4;h5;h6;pre;address\",\"extraPlugins\":[\"pwimage\",\"pwlink\",\"sourcedialog\"],\"removePlugins\":\"image,magicline\",\"toggles\":[2,4,8],\"collapsed\":2,\"label1013\":\"Sidebar\",\"langBlankInherit\":0,\"send_templates\":[29,1,46]}'),
	(44,'FieldtypeImage','images',0,'Imagens','{\"extensions\":\"gif jpg jpeg png\",\"adminThumbs\":1,\"inputfieldClass\":\"InputfieldImage\",\"maxFiles\":0,\"descriptionRows\":1,\"fileSchema\":2,\"outputFormat\":1,\"defaultValuePage\":0,\"defaultGrid\":0,\"icon\":\"camera\",\"label1013\":\"Images\",\"textformatters\":[\"TextformatterEntities\"],\"collapsed\":0,\"maxReject\":0,\"send_templates\":[29,1,44,46]}'),
	(79,'FieldtypeTextareaLanguage','summary',1,'Breve descritivo','{\"textformatters\":[\"TextformatterEntities\"],\"inputfieldClass\":\"InputfieldTextarea\",\"collapsed\":2,\"rows\":3,\"contentType\":0,\"label1013\":\"Summary\",\"langBlankInherit\":0,\"send_templates\":[29,1,44,46,34],\"clone_field\":\"question_title\"}'),
	(76,'FieldtypeTextareaLanguage','body',0,'Texto principal','{\"inputfieldClass\":\"InputfieldCKEditor\",\"rows\":10,\"contentType\":1,\"toolbar\":\"Format, Bold, Italic, -, RemoveFormat\\nNumberedList, BulletedList, -, Blockquote\\nPWLink, Unlink, Anchor\\nPWImage, Table, HorizontalRule, SpecialChar\\nPasteText, PasteFromWord\\nScayt, -, Sourcedialog\",\"inlineMode\":0,\"useACF\":1,\"usePurifier\":1,\"formatTags\":\"p;h2;h3;h4;h5;h6;pre;address\",\"extraPlugins\":[\"pwimage\",\"pwlink\",\"sourcedialog\"],\"removePlugins\":\"image,magicline\",\"toggles\":[2,4,8],\"label1013\":\"Body\",\"langBlankInherit\":0,\"collapsed\":0,\"send_templates\":[29,1,46]}'),
	(78,'FieldtypeTextLanguage','headline',0,'Título alternativo','{\"description\":\"Utilize o campo acima se quiser um t\\u00edtulo maior para a p\\u00e1gina do que para a navega\\u00e7\\u00e3o.\",\"textformatters\":[\"TextformatterEntities\"],\"collapsed\":2,\"size\":0,\"maxlength\":1024,\"langBlankInherit\":1,\"label1013\":\"Headline\",\"description1013\":\"Use this instead of the field above if more text is needed for the page than for the navigation.\",\"send_templates\":[1]}'),
	(104,'FieldtypeRepeater','answers',0,'Respostas','{\"label1013\":\"Answers\",\"template_id\":45,\"parent_id\":1022,\"repeaterReadyItems\":4,\"repeaterFields\":[1,105],\"collapsed\":0,\"send_templates\":[44],\"tags\":\"question-bank\"}'),
	(97,'FieldtypeFile','language_files',24,'Core Translation Files','{\"extensions\":\"json\",\"maxFiles\":0,\"inputfieldClass\":\"InputfieldFile\",\"unzip\":1,\"descriptionRows\":0,\"fileSchema\":2,\"outputFormat\":0,\"defaultValuePage\":0,\"clone_field\":1,\"description\":\"Use this for field for [language packs](http:\\/\\/modules.processwire.com\\/categories\\/language-pack\\/). To delete all files, double-click the trash can for any file, then save.\"}'),
	(98,'FieldtypePage','language',24,'Language','{\"derefAsPage\":1,\"parent_id\":1009,\"labelFieldName\":\"title\",\"inputfield\":\"InputfieldRadios\",\"required\":1}'),
	(100,'FieldtypeFile','language_files_site',24,'Site Translation Files','{\"description\":\"Use this for field for translations specific to your site (like files in \\/site\\/templates\\/ for example).\",\"extensions\":\"json\",\"maxFiles\":0,\"inputfieldClass\":\"InputfieldFile\",\"unzip\":1,\"descriptionRows\":0,\"fileSchema\":2}'),
	(103,'FieldtypeModule','admin_theme',8,'Admin Theme','{\"moduleTypes\":[\"AdminTheme\"],\"labelField\":\"title\",\"inputfieldClass\":\"InputfieldRadios\"}'),
	(105,'FieldtypeCheckbox','is_correct',0,'Correta?','{\"label1013\":\"Correct?\",\"collapsed\":0,\"tags\":\"question-bank\",\"send_templates\":[45]}'),
	(107,'FieldtypeTextareaLanguage','question_title',1,'Título da Questão','{\"textformatters\":[\"TextformatterEntities\"],\"inputfieldClass\":\"InputfieldTextarea\",\"collapsed\":0,\"rows\":2,\"contentType\":0,\"label1013\":\"Question Title\",\"langBlankInherit\":0,\"tags\":\"question-bank\",\"send_templates\":[44]}');

/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table modules
# ------------------------------------------------------------

DROP TABLE IF EXISTS `modules`;

CREATE TABLE `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(128) CHARACTER SET ascii NOT NULL,
  `flags` int(11) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `class` (`class`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;

INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`)
VALUES
	(1,'FieldtypeTextarea',0,'','0000-00-00 00:00:00'),
	(2,'FieldtypeNumber',0,'','0000-00-00 00:00:00'),
	(3,'FieldtypeText',0,'','0000-00-00 00:00:00'),
	(4,'FieldtypePage',0,'','0000-00-00 00:00:00'),
	(30,'InputfieldForm',0,'','0000-00-00 00:00:00'),
	(6,'FieldtypeFile',0,'','0000-00-00 00:00:00'),
	(7,'ProcessPageEdit',1,'','0000-00-00 00:00:00'),
	(10,'ProcessLogin',0,'','0000-00-00 00:00:00'),
	(12,'ProcessPageList',0,'{\"pageLabelField\":\"title\",\"paginationLimit\":25,\"limit\":50}','0000-00-00 00:00:00'),
	(121,'ProcessPageEditLink',1,'','0000-00-00 00:00:00'),
	(14,'ProcessPageSort',0,'','0000-00-00 00:00:00'),
	(15,'InputfieldPageListSelect',0,'','0000-00-00 00:00:00'),
	(117,'JqueryUI',1,'','0000-00-00 00:00:00'),
	(17,'ProcessPageAdd',0,'','0000-00-00 00:00:00'),
	(125,'SessionLoginThrottle',11,'','0000-00-00 00:00:00'),
	(122,'InputfieldPassword',0,'','0000-00-00 00:00:00'),
	(25,'InputfieldAsmSelect',0,'','0000-00-00 00:00:00'),
	(116,'JqueryCore',1,'','0000-00-00 00:00:00'),
	(27,'FieldtypeModule',0,'','0000-00-00 00:00:00'),
	(28,'FieldtypeDatetime',0,'','0000-00-00 00:00:00'),
	(29,'FieldtypeEmail',0,'','0000-00-00 00:00:00'),
	(108,'InputfieldURL',0,'','0000-00-00 00:00:00'),
	(32,'InputfieldSubmit',0,'','0000-00-00 00:00:00'),
	(33,'InputfieldWrapper',0,'','0000-00-00 00:00:00'),
	(34,'InputfieldText',0,'','0000-00-00 00:00:00'),
	(35,'InputfieldTextarea',0,'','0000-00-00 00:00:00'),
	(36,'InputfieldSelect',0,'','0000-00-00 00:00:00'),
	(37,'InputfieldCheckbox',0,'','0000-00-00 00:00:00'),
	(38,'InputfieldCheckboxes',0,'','0000-00-00 00:00:00'),
	(39,'InputfieldRadios',0,'','0000-00-00 00:00:00'),
	(40,'InputfieldHidden',0,'','0000-00-00 00:00:00'),
	(41,'InputfieldName',0,'','0000-00-00 00:00:00'),
	(43,'InputfieldSelectMultiple',0,'','0000-00-00 00:00:00'),
	(45,'JqueryWireTabs',0,'','0000-00-00 00:00:00'),
	(46,'ProcessPage',0,'','0000-00-00 00:00:00'),
	(47,'ProcessTemplate',0,'','0000-00-00 00:00:00'),
	(48,'ProcessField',0,'','0000-00-00 00:00:00'),
	(50,'ProcessModule',0,'','0000-00-00 00:00:00'),
	(114,'PagePermissions',3,'','0000-00-00 00:00:00'),
	(97,'FieldtypeCheckbox',1,'','0000-00-00 00:00:00'),
	(115,'PageRender',3,'{\"clearCache\":1}','0000-00-00 00:00:00'),
	(55,'InputfieldFile',0,'','0000-00-00 00:00:00'),
	(56,'InputfieldImage',0,'','0000-00-00 00:00:00'),
	(57,'FieldtypeImage',0,'','0000-00-00 00:00:00'),
	(60,'InputfieldPage',0,'{\"inputfieldClasses\":[\"InputfieldSelect\",\"InputfieldSelectMultiple\",\"InputfieldCheckboxes\",\"InputfieldRadios\",\"InputfieldAsmSelect\",\"InputfieldPageListSelect\",\"InputfieldPageListSelectMultiple\"]}','0000-00-00 00:00:00'),
	(61,'TextformatterEntities',0,'','0000-00-00 00:00:00'),
	(66,'ProcessUser',0,'{\"showFields\":[\"name\",\"email\",\"roles\"]}','0000-00-00 00:00:00'),
	(67,'MarkupAdminDataTable',0,'','0000-00-00 00:00:00'),
	(68,'ProcessRole',0,'{\"showFields\":[\"name\"]}','0000-00-00 00:00:00'),
	(76,'ProcessList',0,'','0000-00-00 00:00:00'),
	(78,'InputfieldFieldset',0,'','0000-00-00 00:00:00'),
	(79,'InputfieldMarkup',0,'','0000-00-00 00:00:00'),
	(80,'InputfieldEmail',0,'','0000-00-00 00:00:00'),
	(89,'FieldtypeFloat',1,'','0000-00-00 00:00:00'),
	(83,'ProcessPageView',0,'','0000-00-00 00:00:00'),
	(84,'FieldtypeInteger',0,'','0000-00-00 00:00:00'),
	(85,'InputfieldInteger',0,'','0000-00-00 00:00:00'),
	(86,'InputfieldPageName',0,'','0000-00-00 00:00:00'),
	(87,'ProcessHome',0,'','0000-00-00 00:00:00'),
	(90,'InputfieldFloat',0,'','0000-00-00 00:00:00'),
	(94,'InputfieldDatetime',0,'','0000-00-00 00:00:00'),
	(98,'MarkupPagerNav',0,'','0000-00-00 00:00:00'),
	(129,'ProcessPageEditImageSelect',1,'','0000-00-00 00:00:00'),
	(103,'JqueryTableSorter',1,'','0000-00-00 00:00:00'),
	(104,'ProcessPageSearch',1,'{\"searchFields\":\"title\",\"displayField\":\"title path\"}','0000-00-00 00:00:00'),
	(105,'FieldtypeFieldsetOpen',1,'','0000-00-00 00:00:00'),
	(106,'FieldtypeFieldsetClose',1,'','0000-00-00 00:00:00'),
	(107,'FieldtypeFieldsetTabOpen',1,'','0000-00-00 00:00:00'),
	(109,'ProcessPageTrash',1,'','0000-00-00 00:00:00'),
	(111,'FieldtypePageTitle',1,'','0000-00-00 00:00:00'),
	(112,'InputfieldPageTitle',0,'','0000-00-00 00:00:00'),
	(113,'MarkupPageArray',3,'','0000-00-00 00:00:00'),
	(131,'InputfieldButton',0,'','0000-00-00 00:00:00'),
	(133,'FieldtypePassword',1,'','0000-00-00 00:00:00'),
	(134,'ProcessPageType',1,'{\"showFields\":[]}','0000-00-00 00:00:00'),
	(135,'FieldtypeURL',1,'','0000-00-00 00:00:00'),
	(136,'ProcessPermission',1,'{\"showFields\":[\"name\",\"title\"]}','0000-00-00 00:00:00'),
	(137,'InputfieldPageListSelectMultiple',0,'','0000-00-00 00:00:00'),
	(138,'ProcessProfile',1,'{\"profileFields\":[\"pass\",\"email\",\"language\",\"admin_theme\"]}','0000-00-00 00:00:00'),
	(139,'SystemUpdater',1,'{\"systemVersion\":11,\"coreVersion\":\"2.6.14\"}','0000-00-00 00:00:00'),
	(148,'AdminThemeDefault',10,'{\"colors\":\"classic\"}','0000-00-00 00:00:00'),
	(149,'InputfieldSelector',10,'','0000-00-00 00:00:00'),
	(150,'ProcessPageLister',0,'','0000-00-00 00:00:00'),
	(151,'JqueryMagnific',1,'','2014-07-21 07:21:45'),
	(152,'PagePathHistory',3,'','2014-07-25 09:36:57'),
	(155,'InputfieldCKEditor',0,'','2014-07-25 10:26:17'),
	(156,'MarkupHTMLPurifier',0,'','2014-07-25 10:26:17'),
	(158,'LanguageSupport',3,'{\"languagesPageID\":1009,\"defaultLanguagePageID\":1010,\"otherLanguagePageIDs\":{\"1\":1013},\"languageTranslatorPageID\":1011}','2014-09-02 05:45:46'),
	(159,'ProcessLanguage',1,'','2014-09-02 05:45:46'),
	(160,'ProcessLanguageTranslator',1,'','2014-09-02 05:45:46'),
	(161,'LanguageSupportFields',3,'','2014-09-02 05:45:56'),
	(162,'FieldtypeTextLanguage',1,'','2014-09-02 05:45:56'),
	(163,'FieldtypePageTitleLanguage',1,'','2014-09-02 05:45:56'),
	(164,'FieldtypeTextareaLanguage',1,'','2014-09-02 05:45:56'),
	(165,'LanguageSupportPageNames',3,'{\"moduleVersion\":9,\"pageNumUrlPrefix1010\":\"q\",\"useHomeSegment\":\"0\",\"pageNumUrlPrefix1013\":\"q\"}','2014-09-02 05:46:01'),
	(166,'LanguageTabs',11,'','2014-09-02 05:46:12'),
	(168,'ProcessRecentPages',1,'','2015-08-25 15:36:02'),
	(169,'ProcessLogger',1,'','2015-08-25 15:36:14'),
	(170,'InputfieldIcon',0,'','2015-08-25 15:36:14'),
	(171,'AdminThemeReno',10,'{\"colors\":\"\",\"avatar_field_user\":\"\",\"userFields_user\":\"name\",\"notices\":\"fa-bell\",\"home\":\"fa-home\",\"signout\":\"fa-power-off\",\"page\":\"fa-file-text\",\"setup\":\"fa-wrench\",\"module\":\"fa-briefcase\",\"access\":\"fa-unlock\"}','2015-08-25 15:36:50'),
	(172,'FieldtypeRepeater',3,'{\"repeatersRootPageID\":1021}','2015-08-25 15:46:44'),
	(173,'InputfieldRepeater',0,'','2015-08-25 15:46:44'),
	(174,'FieldtypeSelector',1,'','2015-08-25 15:47:14'),
	(175,'ProcessRedirectIds',3,'{\"redirectType\":\"Load\",\"rewriteLinks\":\"\",\"rewriteFormat\":\"\\/{$page->id}\\/\",\"enabledTemplates\":[\"question\"],\"enabledPages\":[1020]}','2015-08-25 16:10:58'),
	(176,'ProcessForgotPassword',1,'','2015-08-25 16:26:01'),
	(177,'FieldtypePageTable',3,'','2015-08-25 16:28:17'),
	(178,'InputfieldPageTable',0,'','2015-08-25 16:28:17'),
	(179,'GenerateQuestionShortTitle',3,'','2015-08-25 18:15:22');

/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table page_path_history
# ------------------------------------------------------------

DROP TABLE IF EXISTS `page_path_history`;

CREATE TABLE `page_path_history` (
  `path` varchar(255) NOT NULL,
  `pages_id` int(10) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`path`),
  KEY `pages_id` (`pages_id`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `page_path_history` WRITE;
/*!40000 ALTER TABLE `page_path_history` DISABLE KEYS */;

INSERT INTO `page_path_history` (`path`, `pages_id`, `created`)
VALUES
	('/dashboard/access/users/admin',41,'2015-08-25 15:36:04'),
	('/dashboard/setup/languages/fi',1013,'2015-08-25 15:40:08'),
	('en',1,'2015-08-25 15:41:39'),
	('/banco-de-questoes',1020,'2015-08-25 15:56:17'),
	('/questoes/2015-08-26-20-54-34',1241,'2015-08-26 20:54:35'),
	('/questoes/2015-08-26-20-18-10',1232,'2015-08-26 20:18:10'),
	('/questoes/2015-08-26-14-24-17',1222,'2015-08-26 14:24:17');

/*!40000 ALTER TABLE `page_path_history` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table pages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pages`;

CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `templates_id` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(128) CHARACTER SET ascii NOT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_users_id` int(10) unsigned NOT NULL DEFAULT '2',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_users_id` int(10) unsigned NOT NULL DEFAULT '2',
  `sort` int(11) NOT NULL DEFAULT '0',
  `name1013` varchar(128) CHARACTER SET ascii DEFAULT NULL,
  `status1013` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_parent_id` (`name`,`parent_id`),
  UNIQUE KEY `name1013_parent_id` (`name1013`,`parent_id`),
  KEY `parent_id` (`parent_id`),
  KEY `templates_id` (`templates_id`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;

INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `sort`, `name1013`, `status1013`)
VALUES
	(1,0,1,'',9,'2015-08-25 15:41:47',41,'0000-00-00 00:00:00',2,0,'en',1),
	(2,1,2,'dashboard',1035,'2015-08-25 15:36:04',40,'0000-00-00 00:00:00',2,5,NULL,1),
	(3,2,2,'page',21,'2011-03-29 21:37:06',41,'0000-00-00 00:00:00',2,0,NULL,1),
	(6,3,2,'add',21,'2015-08-25 15:36:20',40,'0000-00-00 00:00:00',2,0,NULL,1),
	(7,1,2,'trash',1039,'2011-08-14 22:04:52',41,'2010-02-07 05:29:39',2,6,NULL,1),
	(8,3,2,'list',21,'2011-03-29 21:37:06',41,'0000-00-00 00:00:00',2,1,NULL,1),
	(9,3,2,'sort',1047,'2011-03-29 21:37:06',41,'0000-00-00 00:00:00',2,2,NULL,1),
	(10,3,2,'edit',1045,'2011-03-29 21:37:06',41,'0000-00-00 00:00:00',2,3,NULL,1),
	(11,22,2,'template',21,'2011-03-29 21:37:06',41,'2010-02-01 11:04:54',2,0,NULL,1),
	(16,22,2,'field',21,'2011-03-29 21:37:06',41,'2010-02-01 12:44:07',2,2,NULL,1),
	(21,2,2,'module',21,'2011-03-29 21:37:06',41,'2010-02-02 10:02:24',2,2,NULL,1),
	(22,2,2,'setup',21,'2011-03-29 21:37:06',41,'2010-02-09 12:16:59',2,1,NULL,1),
	(23,2,2,'login',1035,'2011-05-03 23:38:10',41,'2010-02-17 09:59:39',2,4,NULL,1),
	(27,1,29,'http404',1035,'2014-09-02 11:32:16',41,'2010-06-03 06:53:03',3,4,NULL,1),
	(28,2,2,'access',13,'2011-05-03 23:38:10',41,'2011-03-19 19:14:20',2,3,NULL,1),
	(29,28,2,'users',29,'2011-04-05 00:39:08',41,'2011-03-19 19:15:29',2,0,NULL,1),
	(30,28,2,'roles',29,'2011-04-05 00:38:39',41,'2011-03-19 19:15:45',2,1,NULL,1),
	(31,28,2,'permissions',29,'2011-04-05 00:53:52',41,'2011-03-19 19:16:00',2,2,NULL,1),
	(32,31,5,'page-edit',25,'2011-09-06 15:34:24',41,'2011-03-19 19:17:03',2,2,NULL,1),
	(34,31,5,'page-delete',25,'2011-09-06 15:34:33',41,'2011-03-19 19:17:23',2,3,NULL,1),
	(35,31,5,'page-move',25,'2011-09-06 15:34:48',41,'2011-03-19 19:17:41',2,4,NULL,1),
	(36,31,5,'page-view',25,'2011-09-06 15:34:14',41,'2011-03-19 19:17:57',2,0,NULL,1),
	(37,30,4,'guest',25,'2011-04-05 01:37:19',41,'2011-03-19 19:18:41',2,0,NULL,1),
	(38,30,4,'superuser',25,'2011-08-17 14:34:39',41,'2011-03-19 19:18:55',2,1,NULL,1),
	(41,29,3,'sjardim',1,'2015-08-25 16:36:46',41,'2011-03-19 19:41:26',2,0,NULL,1),
	(40,29,3,'guest',25,'2015-08-25 15:37:32',41,'2011-03-20 17:31:59',2,1,NULL,1),
	(50,31,5,'page-sort',25,'2011-09-06 15:34:58',41,'2011-03-26 22:04:50',41,5,NULL,1),
	(51,31,5,'page-template',25,'2011-09-06 15:35:09',41,'2011-03-26 22:25:31',41,6,NULL,1),
	(52,31,5,'user-admin',25,'2011-09-06 15:35:42',41,'2011-03-30 00:06:47',41,10,NULL,1),
	(53,31,5,'profile-edit',1,'2011-08-16 22:32:48',41,'2011-04-26 00:02:22',41,13,NULL,1),
	(54,31,5,'page-lock',1,'2011-08-15 17:48:12',41,'2011-08-15 17:45:48',41,8,NULL,1),
	(300,3,2,'search',1045,'2011-03-29 21:37:06',41,'2010-08-04 05:23:59',2,5,NULL,1),
	(301,3,2,'trash',1047,'2011-03-29 21:37:06',41,'2010-09-28 05:39:30',2,5,NULL,1),
	(302,3,2,'link',1041,'2011-03-29 21:37:06',41,'2010-10-01 05:03:56',2,6,NULL,1),
	(303,3,2,'image',1041,'2011-03-29 21:37:06',41,'2010-10-13 03:56:48',2,7,NULL,1),
	(304,2,2,'profile',1025,'2011-05-03 23:38:10',41,'2011-04-25 23:57:18',41,5,NULL,1),
	(1000,1,26,'search',1025,'2014-09-02 11:06:44',41,'2010-09-06 05:05:28',2,3,'haku',1),
	(1001,1,29,'about',1,'2014-09-04 11:09:58',41,'2010-10-25 22:39:33',2,0,'tietoja',1),
	(1002,1001,29,'child-page-example-1',1,'2014-09-04 11:10:53',41,'2010-10-25 23:21:34',2,0,'alasivu-sivu-esimerkki-1',1),
	(1004,1001,29,'child-page-example-2',1,'2014-09-02 11:04:51',41,'2010-11-29 22:11:36',2,1,'alasivu-esimerkki-2',1),
	(1005,1,34,'site-map',1,'2014-09-04 11:12:40',41,'2010-11-30 21:16:49',2,2,'sivukartta',1),
	(1006,31,5,'page-lister',1,'2014-07-20 09:00:38',40,'2014-07-20 09:00:38',40,9,NULL,1),
	(1007,3,2,'lister',1,'2014-07-20 09:00:38',40,'2014-07-20 09:00:38',40,8,NULL,1),
	(1009,22,2,'languages',16,'2014-09-02 05:45:46',41,'2014-09-02 05:45:46',41,2,NULL,1),
	(1010,1009,43,'default',16,'2015-08-25 15:39:44',41,'2014-09-02 05:45:46',41,0,NULL,1),
	(1011,22,2,'language-translator',1040,'2014-09-02 05:45:46',41,'2014-09-02 05:45:46',41,3,NULL,1),
	(1020,1,46,'questoes',1,'2015-08-25 15:56:17',41,'2015-08-25 15:41:23',41,6,'questions',1),
	(1013,1009,43,'en',1,'2015-08-25 15:40:21',41,'2014-09-02 05:48:16',41,2,NULL,1),
	(1015,3,2,'recent-pages',1,'2015-08-25 15:36:02',40,'2015-08-25 15:36:02',40,9,NULL,0),
	(1016,31,5,'page-edit-recent',1,'2015-08-25 15:36:02',40,'2015-08-25 15:36:02',40,10,NULL,1),
	(1017,22,2,'logs',1,'2015-08-25 15:36:14',40,'2015-08-25 15:36:14',40,4,NULL,0),
	(1018,31,5,'logs-view',1,'2015-08-25 15:36:14',40,'2015-08-25 15:36:14',40,11,NULL,1),
	(1019,31,5,'logs-edit',1,'2015-08-25 15:36:14',40,'2015-08-25 15:36:14',40,12,NULL,1),
	(1021,2,2,'repeaters',1036,'2015-08-25 15:46:44',41,'2015-08-25 15:46:44',41,6,NULL,0),
	(1022,1021,2,'for-field-104',17,'2015-08-25 15:47:59',41,'2015-08-25 15:47:59',41,0,NULL,0),
	(1224,1223,45,'1440609858-15-1',1,'2015-08-26 18:47:49',41,'2015-08-26 14:24:18',41,0,NULL,1),
	(1225,1223,45,'1440609858-19-2',1,'2015-08-26 18:47:49',41,'2015-08-26 14:24:18',41,1,NULL,1),
	(1226,1223,45,'1440609858-21-3',1,'2015-08-26 18:47:49',41,'2015-08-26 14:24:18',41,2,NULL,1),
	(1227,1223,45,'1440609858-23-4',1,'2015-08-26 18:47:49',41,'2015-08-26 14:24:18',41,3,NULL,1),
	(1228,1223,45,'1440609897-09-1',3073,'2015-08-26 14:24:57',41,'2015-08-26 14:24:57',41,4,NULL,1),
	(1229,1223,45,'1440609897-12-2',3073,'2015-08-26 14:24:57',41,'2015-08-26 14:24:57',41,5,NULL,1),
	(1230,1223,45,'1440625670-14-1',3073,'2015-08-26 18:47:50',41,'2015-08-26 18:47:50',41,6,NULL,1),
	(1231,1223,45,'1440625670-17-2',3073,'2015-08-26 18:47:50',41,'2015-08-26 18:47:50',41,7,NULL,1),
	(1232,1020,44,'1232',1,'2015-08-26 20:19:54',41,'2015-08-26 20:18:10',41,1,NULL,1),
	(1233,1022,2,'for-page-1232',17,'2015-08-26 20:18:10',41,'2015-08-26 20:18:10',41,3,NULL,0),
	(1234,1233,45,'1440631090-92-1',1,'2015-08-26 20:18:45',41,'2015-08-26 20:18:10',41,0,NULL,1),
	(1235,1233,45,'1440631090-96-2',1,'2015-08-26 20:18:45',41,'2015-08-26 20:18:10',41,1,NULL,1),
	(1241,1020,44,'1241',1,'2015-08-26 20:56:09',41,'2015-08-26 20:54:34',41,2,NULL,1),
	(1237,1233,45,'1440631091-4',3073,'2015-08-26 20:18:10',41,'2015-08-26 20:18:10',41,3,NULL,1),
	(1238,1233,45,'1440631126-01-1',3073,'2015-08-26 20:18:46',41,'2015-08-26 20:18:46',41,4,NULL,1),
	(1239,1233,45,'1440631126-05-2',3073,'2015-08-26 20:18:46',41,'2015-08-26 20:18:46',41,5,NULL,1),
	(1240,1233,45,'1440631126-08-3',3073,'2015-08-26 20:18:46',41,'2015-08-26 20:18:46',41,6,NULL,1),
	(1242,1022,2,'for-page-1241',17,'2015-08-26 20:54:35',41,'2015-08-26 20:54:35',41,4,NULL,0),
	(1243,1242,45,'1440633275-38-1',1,'2015-08-26 20:56:09',41,'2015-08-26 20:54:35',41,0,NULL,1),
	(1244,1242,45,'1440633275-42-2',1,'2015-08-26 20:56:09',41,'2015-08-26 20:54:35',41,1,NULL,1),
	(1245,1242,45,'1440633275-44-3',3073,'2015-08-26 20:54:35',41,'2015-08-26 20:54:35',41,2,NULL,1),
	(1246,1242,45,'1440633275-46-4',3073,'2015-08-26 20:54:35',41,'2015-08-26 20:54:35',41,3,NULL,1),
	(1247,1242,45,'1440633369-66-1',3073,'2015-08-26 20:56:09',41,'2015-08-26 20:56:09',41,4,NULL,1),
	(1248,1242,45,'1440633369-7-2',3073,'2015-08-26 20:56:09',41,'2015-08-26 20:56:09',41,5,NULL,1),
	(1222,1020,44,'1222',1,'2015-08-26 20:54:24',41,'2015-08-26 14:24:17',41,0,NULL,1),
	(1223,1022,2,'for-page-1222',17,'2015-08-26 14:24:17',41,'2015-08-26 14:24:17',41,2,NULL,0),
	(1069,1022,2,'digite-o-titulo-da-quest-ao',17,'2015-08-25 19:26:08',41,'2015-08-25 19:26:08',41,0,NULL,0),
	(1070,1022,2,'quest-ao-de-id-0',17,'2015-08-25 19:27:31',41,'2015-08-25 19:27:31',41,1,NULL,0);

/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table pages_access
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pages_access`;

CREATE TABLE `pages_access` (
  `pages_id` int(11) NOT NULL,
  `templates_id` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pages_id`),
  KEY `templates_id` (`templates_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `pages_access` WRITE;
/*!40000 ALTER TABLE `pages_access` DISABLE KEYS */;

INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`)
VALUES
	(37,2,'2011-09-06 12:10:09'),
	(38,2,'2011-09-06 12:10:09'),
	(32,2,'2011-09-06 12:10:09'),
	(34,2,'2011-09-06 12:10:09'),
	(35,2,'2011-09-06 12:10:09'),
	(36,2,'2011-09-06 12:10:09'),
	(50,2,'2011-09-06 12:10:09'),
	(51,2,'2011-09-06 12:10:09'),
	(52,2,'2011-09-06 12:10:09'),
	(53,2,'2011-09-06 12:10:09'),
	(54,2,'2011-09-06 12:10:09'),
	(1006,2,'2014-07-20 09:00:38'),
	(1010,2,'2014-09-02 05:45:46'),
	(1020,1,'2015-08-25 15:41:23'),
	(1013,2,'2014-09-02 05:48:16'),
	(1016,2,'2015-08-25 15:36:02'),
	(1018,2,'2015-08-25 15:36:14'),
	(1019,2,'2015-08-25 15:36:14'),
	(1225,2,'2015-08-26 14:24:18'),
	(1229,2,'2015-08-26 14:24:57'),
	(1228,2,'2015-08-26 14:24:57'),
	(1224,2,'2015-08-26 14:24:18'),
	(1240,2,'2015-08-26 20:18:46'),
	(1226,2,'2015-08-26 14:24:18'),
	(1245,2,'2015-08-26 20:54:35'),
	(1244,2,'2015-08-26 20:54:35'),
	(1243,2,'2015-08-26 20:54:35'),
	(1235,2,'2015-08-26 20:18:10'),
	(1239,2,'2015-08-26 20:18:46'),
	(1238,2,'2015-08-26 20:18:46'),
	(1237,2,'2015-08-26 20:18:11'),
	(1241,1,'2015-08-26 20:54:35'),
	(1230,2,'2015-08-26 18:47:50'),
	(1232,1,'2015-08-26 20:18:10'),
	(1231,2,'2015-08-26 18:47:50'),
	(1222,1,'2015-08-26 14:24:17'),
	(1227,2,'2015-08-26 14:24:18'),
	(1248,2,'2015-08-26 20:56:09'),
	(1234,2,'2015-08-26 20:18:10'),
	(1247,2,'2015-08-26 20:56:09'),
	(1246,2,'2015-08-26 20:54:35');

/*!40000 ALTER TABLE `pages_access` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table pages_parents
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pages_parents`;

CREATE TABLE `pages_parents` (
  `pages_id` int(10) unsigned NOT NULL,
  `parents_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`parents_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `pages_parents` WRITE;
/*!40000 ALTER TABLE `pages_parents` DISABLE KEYS */;

INSERT INTO `pages_parents` (`pages_id`, `parents_id`)
VALUES
	(2,1),
	(3,1),
	(3,2),
	(7,1),
	(22,1),
	(22,2),
	(28,1),
	(28,2),
	(29,1),
	(29,2),
	(29,28),
	(30,1),
	(30,2),
	(30,28),
	(31,1),
	(31,2),
	(31,28),
	(1001,1),
	(1002,1),
	(1002,1001),
	(1004,1),
	(1004,1001),
	(1005,1),
	(1009,1),
	(1009,2),
	(1009,22),
	(1020,1),
	(1021,1),
	(1021,2),
	(1022,1),
	(1022,2),
	(1022,1021),
	(1223,1),
	(1223,2),
	(1223,1021),
	(1223,1022),
	(1233,1),
	(1233,2),
	(1233,1021),
	(1233,1022),
	(1242,1),
	(1242,2),
	(1242,1021),
	(1242,1022);

/*!40000 ALTER TABLE `pages_parents` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table pages_sortfields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pages_sortfields`;

CREATE TABLE `pages_sortfields` (
  `pages_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sortfield` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`pages_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table process_forgot_password
# ------------------------------------------------------------

DROP TABLE IF EXISTS `process_forgot_password`;

CREATE TABLE `process_forgot_password` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `token` char(32) NOT NULL,
  `ts` int(10) unsigned NOT NULL,
  `ip` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `token` (`token`),
  KEY `ts` (`ts`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=ascii;



# Dump of table session_login_throttle
# ------------------------------------------------------------

DROP TABLE IF EXISTS `session_login_throttle`;

CREATE TABLE `session_login_throttle` (
  `name` varchar(128) NOT NULL,
  `attempts` int(10) unsigned NOT NULL DEFAULT '0',
  `last_attempt` int(10) unsigned NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `session_login_throttle` WRITE;
/*!40000 ALTER TABLE `session_login_throttle` DISABLE KEYS */;

INSERT INTO `session_login_throttle` (`name`, `attempts`, `last_attempt`)
VALUES
	('sjardim',1,1440604409);

/*!40000 ALTER TABLE `session_login_throttle` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table templates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `templates`;

CREATE TABLE `templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET ascii NOT NULL,
  `fieldgroups_id` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` int(11) NOT NULL DEFAULT '0',
  `cache_time` mediumint(9) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `fieldgroups_id` (`fieldgroups_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `templates` WRITE;
/*!40000 ALTER TABLE `templates` DISABLE KEYS */;

INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`)
VALUES
	(2,'admin',2,8,0,'{\"useRoles\":1,\"parentTemplates\":[2],\"allowPageNum\":1,\"redirectLogin\":23,\"slashUrls\":1,\"noGlobal\":1,\"modified\":1440167712}'),
	(3,'user',3,8,0,'{\"useRoles\":1,\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"User\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}'),
	(4,'role',4,8,0,'{\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"Role\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}'),
	(5,'permission',5,8,0,'{\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"guestSearchable\":1,\"pageClass\":\"Permission\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}'),
	(1,'home',1,0,0,'{\"useRoles\":1,\"noParents\":1,\"slashUrls\":1,\"label\":\"Home\",\"modified\":1440527873,\"label1013\":\"Koti\",\"roles\":[37]}'),
	(29,'basic-page',83,0,0,'{\"slashUrls\":1,\"label\":\"Basic Page\",\"modified\":1440527873,\"label1013\":\"Perus Sivu\"}'),
	(26,'search',80,0,0,'{\"noChildren\":1,\"noParents\":1,\"allowPageNum\":1,\"slashUrls\":1,\"label\":\"Search\",\"modified\":1440527873,\"label1013\":\"Haku\"}'),
	(34,'sitemap',88,0,0,'{\"noChildren\":1,\"noParents\":1,\"redirectLogin\":23,\"slashUrls\":1,\"label\":\"Site Map\",\"modified\":1440527873,\"label1013\":\"Sivukartta\"}'),
	(43,'language',97,8,0,'{\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"Language\",\"pageLabelField\":\"name\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noChangeTemplate\":1,\"noUnpublish\":1,\"nameContentTab\":1,\"modified\":1409651146}'),
	(44,'question',98,0,0,'{\"noChildren\":1,\"parentTemplates\":[46],\"slashUrls\":1,\"pageLabelField\":\"title\",\"noChangeTemplate\":1,\"label\":\"Quest\\u00e3o\",\"modified\":1440632047,\"noPrependTemplateFile\":1,\"noAppendTemplateFile\":1,\"label1013\":\"Question\"}'),
	(45,'repeater_answer',99,8,0,'{\"noChildren\":1,\"noParents\":1,\"slashUrls\":1,\"noGlobal\":1,\"modified\":1440528479}'),
	(46,'question-bank',100,0,0,'{\"sortfield\":\"-created\",\"noParents\":1,\"childTemplates\":[44],\"allowPageNum\":1,\"slashUrls\":1,\"childNameFormat\":\"\\\"Y\\/m\\/d H:i:s\\\"\",\"label\":\"Banco de quest\\u00f5es\",\"modified\":1440653379,\"noPrependTemplateFile\":1,\"noAppendTemplateFile\":1,\"label1013\":\"Question bank\"}');

/*!40000 ALTER TABLE `templates` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
